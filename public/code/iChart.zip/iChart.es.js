var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import * as echarts from "echarts";
const BaseOption$7 = {
  color: [],
  grid: {
    top: "0",
    left: "0",
    right: "0",
    bottom: "0",
    containLabel: true
  },
  legend: {},
  tooltip: {},
  xAxis: {},
  yAxis: {}
};
function getColor(colors, index) {
  return colors[index % colors.length];
}
function codeToRGB(code, opacity) {
  if (code == void 0) {
    return void 0;
  }
  const result = [];
  result.push(parseInt(code.substring(1, 3), 16));
  result.push(parseInt(code.substring(3, 5), 16));
  result.push(parseInt(code.substring(5), 16));
  return `rgba(${result.join(",")},${opacity})`;
}
function changeRgbaOpacity(rgba, opacity) {
  const [r, g, b] = rgba.match(/\d+(\.\d+)?/g);
  return `rgba(${r},${g},${b},${opacity})`;
}
function getTextWidth(text, fontSize) {
  let result = 0;
  const ele = document.createElement("span");
  ele.innerText = text;
  ele.style.fontSize = fontSize;
  ele.setAttribute("style", "font-size: 12px");
  document.documentElement.append(ele);
  result = ele.offsetWidth;
  document.documentElement.removeChild(ele);
  return result;
}
function cloneDeep(obj) {
  const objClone = Array.isArray(obj) ? [] : {};
  if (obj && typeof obj === "object") {
    for (const key in obj) {
      if (obj[key] && typeof obj[key] === "object") {
        objClone[key] = cloneDeep(obj[key]);
      } else {
        objClone[key] = obj[key];
      }
    }
  }
  return objClone;
}
function isArray(data2) {
  return Object.prototype.toString.call(data2) === "[object Array]" ? true : false;
}
const isFunction = (value) => typeof value === "function";
function getRandom() {
  const array = new Uint32Array(1);
  self.crypto.getRandomValues(array);
  const random = parseFloat(`0.${array[0].toString()}`);
  return random;
}
const lightColorGroup = [
  "#6d8ff0",
  "#00a874",
  "#bd72f0",
  "#c6e5ec",
  "#fdc000",
  "#9185f0"
];
const darkColorGroup = [
  "#1f55b5",
  "#278661",
  "#8a21bc",
  "#26616b",
  "#b98c1d",
  "#745ef7"
];
const darkColor = "#191919";
const darkFontColor = "#f5f5f5";
const darkSecondaryFontColor = "#4e4e4e";
const darkAxis = "rgba(238,238,238,0.1)";
const darkAxisLabel = "#bbbbbb";
const darkSecondaryColor = "#2e2e2e";
const darkBackgroundColor = "#191919";
const lightColor = "#ffffff";
const lightFontColor = "#191919";
const lightSecondaryFontColor = "#bbbbbb";
const lightAxis = "rgba(25,25,25,0.1)";
const lightAxisLabel = "#4e4e4e";
const lightSecondaryColor = "#e8e8e8";
const lightBackgroundColor = "#ffffff";
const marklineColor = "#f43146";
function setDefaultTheme(iChartOption) {
  iChartOption.theme = iChartOption.theme || "light";
}
function setDefaultColor(iChartOption) {
  if (!iChartOption.color) {
    const theme = iChartOption.theme;
    switch (theme) {
      case "light":
        iChartOption.color = cloneDeep(lightColorGroup);
        break;
      default:
        iChartOption.color = cloneDeep(darkColorGroup);
        break;
    }
  }
}
function setDefaultXAxis(iChartOption) {
  const data2 = iChartOption.data;
  if (data2 && data2.length > 0) {
    const keys = Object.keys(data2[0]);
    for (let i = 0; i < keys.length; i++) {
      iChartOption.xAxis = keys[i];
      break;
    }
  }
}
function setChartPadding$2(iChartOption) {
  const defaultPadding = [50, 20, 50, 20];
  if (!iChartOption.chartPadding) {
    iChartOption.chartPadding = defaultPadding;
  } else if (iChartOption.chartPadding.length === 1) {
    iChartOption.chartPadding = [iChartOption.chartPadding[0], 20, iChartOption.chartPadding[0], 20];
  } else if (iChartOption.chartPadding.length === 2) {
    iChartOption.chartPadding = [
      iChartOption.chartPadding[0],
      iChartOption.chartPadding[1],
      iChartOption.chartPadding[0],
      iChartOption.chartPadding[1]
    ];
  } else if (iChartOption.chartPadding.length === 3) {
    iChartOption.chartPadding = [
      iChartOption.chartPadding[0],
      iChartOption.chartPadding[1],
      iChartOption.chartPadding[2],
      iChartOption.chartPadding[1]
    ];
  }
}
function setDefaultLegend(iChartOption) {
  if (!iChartOption.legend) {
    iChartOption.legend = {
      show: true,
      position: {
        left: "center",
        bottom: 14
      },
      orient: "horizontal"
    };
  }
  if (iChartOption.legend.show === void 0) {
    iChartOption.legend.show = false;
  }
  if (!iChartOption.legend.orient) {
    iChartOption.legend.orient = "horizontal";
  }
  if (!iChartOption.legend.position) {
    iChartOption.legend.position = {
      left: "center",
      bottom: 15
    };
  }
}
function setDefaultDataZoom(iChartOption) {
  if (!iChartOption.dataZoom) {
    iChartOption.dataZoom = {
      show: false,
      position: {
        left: 40,
        bottom: 18
      }
    };
  }
  if (iChartOption.dataZoom.show === void 0) {
    iChartOption.dataZoom.show = false;
  }
  if (!iChartOption.dataZoom.position) {
    iChartOption.dataZoom.position = {
      left: "center",
      bottom: 20
    };
  }
}
function setIChartOption(iChartOption) {
  setDefaultTheme(iChartOption);
  setDefaultColor(iChartOption);
  setDefaultXAxis(iChartOption);
  setChartPadding$2(iChartOption);
  setDefaultLegend(iChartOption);
  setDefaultDataZoom(iChartOption);
  return iChartOption;
}
function getSeriesData(data2, legendData) {
  const seriesData2 = {};
  legendData.forEach((legend) => {
    seriesData2[legend] = [];
  });
  data2.forEach((item) => {
    legendData.forEach((legend) => {
      seriesData2[legend].push(item[legend]);
    });
  });
  return seriesData2;
}
function getLegendData$2(data2, xAxisKey) {
  const legendData = [];
  if (data2.length > 0) {
    const temp = data2[0];
    for (const key in temp) {
      if (key !== xAxisKey) {
        legendData.push(key);
      }
    }
  }
  return legendData;
}
function getXAxisData$1(data2, xAxisKey) {
  const xAxisData = [];
  data2.forEach((item) => {
    xAxisData.push(item[xAxisKey]);
  });
  return xAxisData;
}
function min(arrMin) {
  function handleMin(arrMin2) {
    return arrMin2.map((item) => {
      return Object.prototype.toString.call(item) === "[object Number]" ? item : 0;
    });
  }
  function heapJustMin(dataMin, iMin, length) {
    let childMin = 2 * iMin + 1;
    while (childMin <= length) {
      const temp = dataMin[iMin];
      if (childMin + 1 <= length && dataMin[childMin] < dataMin[childMin + 1]) {
        childMin = childMin + 1;
      }
      if (dataMin[iMin] < dataMin[childMin]) {
        dataMin[iMin] = dataMin[childMin];
        dataMin[childMin] = temp;
        iMin = childMin;
        childMin = 2 * iMin + 1;
      } else {
        break;
      }
    }
  }
  function buildHeapMin(dataMin) {
    for (let iMin = Math.floor(dataMin.length / 2); iMin >= 0; iMin--) {
      heapJustMin(dataMin, iMin, dataMin.length);
    }
  }
  function swap(arrMin2, iMin, jMin) {
    const temp = arrMin2[iMin];
    arrMin2[iMin] = arrMin2[jMin];
    arrMin2[jMin] = temp;
  }
  function heapSort(arrMin2) {
    const dataMin = handleMin(arrMin2).slice(0);
    if (!(dataMin instanceof Array))
      return;
    if (dataMin instanceof Array && dataMin.length == 1) {
      return dataMin;
    }
    buildHeapMin(dataMin);
    for (let iMin = dataMin.length - 1; iMin >= 0; iMin--) {
      swap(dataMin, iMin, 0);
      heapJustMin(dataMin, 0, iMin - 1);
    }
    return dataMin[0];
  }
  return heapSort(arrMin);
}
function max(arr) {
  function handle(arr2) {
    return arr2.map((item) => {
      return Object.prototype.toString.call(item) === "[object Number]" ? item : 0;
    });
  }
  function heapAjust(data2, i, length) {
    let child = 2 * i + 1;
    while (child <= length) {
      const temp = data2[i];
      if (child + 1 <= length && data2[child] < data2[child + 1]) {
        child = child + 1;
      }
      if (data2[i] < data2[child]) {
        data2[i] = data2[child];
        data2[child] = temp;
        i = child;
        child = 2 * i + 1;
      } else {
        break;
      }
    }
  }
  function buildHeap(data2) {
    for (let i = Math.floor(data2.length / 2); i >= 0; i--) {
      heapAjust(data2, i, data2.length);
    }
  }
  function swap(arr2, i, j) {
    const temp = arr2[i];
    arr2[i] = arr2[j];
    arr2[j] = temp;
  }
  function heapSort(arr2) {
    const data2 = handle(arr2).slice(0);
    if (!(data2 instanceof Array))
      return;
    if (data2 instanceof Array && data2.length == 1) {
      return data2;
    }
    buildHeap(data2);
    for (let i = data2.length - 1; i >= 0; i--) {
      swap(data2, i, 0);
      heapAjust(data2, 0, i - 1);
    }
    return data2[data2.length - 1];
  }
  return heapSort(arr);
}
const markLineDefault = {
  symbol: "none",
  silent: true,
  label: {
    show: false,
    color: "red"
  },
  lineStyle: {
    width: 1,
    color: "red"
  },
  emphasis: {
    label: {
      show: false
    },
    lineStyle: {
      width: 1
    }
  },
  data: []
};
const markPointDefault = {
  symbol: "path://M50 0 L0 50 L100 50 Z",
  symbolSize: [10, 6],
  itemStyle: {
    color: "#f43146"
  },
  label: {
    color: "transparent"
  },
  data: []
};
const seriesInit$6 = {
  label: { show: false },
  symbol: "circle",
  symbolSize: 10,
  showSymbol: false,
  data: [],
  type: "line",
  lineStyle: {
    width: 2
  },
  step: false,
  smooth: false,
  markLine: null,
  markPoint: null,
  itemStyle: {
    normal: {
      borderColor: "#FFFFFF",
      borderWidth: 3,
      shadowColor: "rgba(0, 0, 0, .2)",
      shadowBlur: 10
    }
  }
};
function handleMarkLine$1(markLine, seriesUnit) {
  if (markLine) {
    seriesUnit.markLine = cloneDeep(markLineDefault);
    if (markLine.top) {
      const markLineData = { yAxis: markLine.top };
      markLineData.label = { show: false, position: "insideEndTop" };
      markLineData.lineStyle = {};
      markLine.topPosition && (markLineData.label.position = markLine.topPosition || "insideStartTop");
      markLine.topLabel && (markLineData.label.show = true);
      markLine.topLabel && (markLineData.label.formatter = markLine.topLabel);
      markLine.topColor && (markLineData.label.color = markLine.topColor);
      markLine.topColor && (markLineData.lineStyle.color = markLine.topColor);
      seriesUnit.markLine.data.push(markLineData);
    }
    if (markLine.bottom) {
      const markLineData = { yAxis: markLine.bottom };
      markLineData.label = { show: false, position: "insideEndTop" };
      markLineData.lineStyle = {};
      markLine.bottomPosition && (markLineData.label.position = markLine.bottomPosition || "insideStartTop");
      markLine.bottomLabel && (markLineData.label.show = true);
      markLine.bottomLabel && (markLineData.label.formatter = markLine.bottomLabel);
      markLine.bottomColor && (markLineData.label.color = markLine.bottomColor);
      markLine.bottomColor && (markLineData.lineStyle.color = markLine.bottomColor);
      seriesUnit.markLine.data.push(markLineData);
    }
  }
}
function handleMarkPoint(markPoint, seriesUnit) {
  if (markPoint) {
    seriesUnit.markPoint = cloneDeep(markPointDefault);
    markPoint.max && seriesUnit.markPoint.data.push({ type: "max", symbolOffset: [0, -11] });
    markPoint.min && seriesUnit.markPoint.data.push({ type: "min", symbolOffset: [0, 11], symbolRotate: 180 });
  }
}
function handleLabel(labelHtml, seriesUnit, theme) {
  if (labelHtml) {
    seriesUnit.showSymbol = true;
    seriesUnit.label.show = true;
    seriesUnit.label.formatter = labelHtml;
    seriesUnit.label.textStyle = {
      color: theme == "dark" ? darkFontColor : lightFontColor,
      fontSize: 14
    };
  }
}
function handleAreaStyleTop(colorFroma, colorTo) {
  const zeroc = 0;
  const onec = 1;
  const areaStyleTop = {
    color: {
      type: "linear",
      x: zeroc,
      y: zeroc,
      x2: zeroc,
      y2: onec,
      colorStops: [
        {
          offset: zeroc,
          color: colorFroma
        },
        {
          offset: onec,
          color: colorTo
        }
      ]
    }
  };
  return areaStyleTop;
}
function handleAreaStyleBottom(topColor, percent, colorFrom, colorTo) {
  const areaStyleBottom = {
    color: {
      type: "linear",
      x: 0,
      y: 0,
      x2: 0,
      y2: 1,
      colorStops: [
        {
          offset: 0,
          color: topColor
        },
        {
          offset: percent,
          color: topColor
        },
        {
          offset: percent + 1e-5,
          color: colorFrom
        },
        {
          offset: 1,
          color: colorTo
        }
      ]
    }
  };
  return areaStyleBottom;
}
function setTopAreaStyle(index, colors, markLine, maxValue) {
  const topColor = codeToRGB(markLine.topColor, 0.3) || "rgba(244,49,70,0.3)";
  const color2 = getColor(colors, index);
  const colorFrom = codeToRGB(color2, 0.25);
  const colorTo = codeToRGB(color2, 0);
  const percent = (maxValue - markLine.top) / (maxValue - 0);
  let areaStyle = {};
  if (maxValue <= markLine.top) {
    areaStyle = handleAreaStyleTop(colorFrom, colorTo);
  } else {
    areaStyle = handleAreaStyleBottom(topColor, percent, colorFrom, colorTo);
  }
  return areaStyle;
}
function setSplitTopAreaStyle(index, colors, splitLine, maxValue) {
  const color2 = getColor(colors, index);
  const colorFrom = codeToRGB(color2, 0.25);
  const colorTo = codeToRGB(color2, 0.1);
  const percent = (maxValue - splitLine) / (maxValue - 0);
  const areaStyle = {
    color: {
      type: "linear",
      x: 0,
      y: 0,
      x2: 0,
      y2: 1,
      colorStops: [
        {
          offset: 0,
          color: colorFrom
        },
        {
          offset: percent,
          color: colorTo
        },
        {
          offset: percent + 1e-5,
          color: "rgba(0,0,0,0)"
        },
        {
          offset: 1,
          color: "rgba(0,0,0,0)"
        }
      ]
    }
  };
  return areaStyle;
}
function setNormalAreaStyle(index, colors) {
  const color2 = getColor(colors, index);
  const colorFrom = codeToRGB(color2, 0.25);
  const colorTo = codeToRGB(color2, 0);
  const areaStyle = {
    opacity: 1,
    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
      {
        offset: 0,
        color: colorFrom
      },
      {
        offset: 1,
        color: colorTo
      }
    ])
  };
  return areaStyle;
}
function handleIsArea({ isArea, markLine, seriesData: seriesData2, legend, yAxisOption, seriesUnit, splitLine, index, colors }) {
  if (isArea) {
    if (markLine && markLine.top) {
      const maxValue = max(seriesData2[legend]);
      (yAxisOption == null ? void 0 : yAxisOption.min) || 0;
      seriesUnit.areaStyle = setTopAreaStyle(index, colors, markLine, maxValue);
    } else if (splitLine) {
      const maxValue = max(seriesData2[legend]);
      seriesUnit.areaStyle = setSplitTopAreaStyle(index, colors, splitLine, maxValue);
    } else {
      seriesUnit.areaStyle = setNormalAreaStyle(index, colors);
    }
  }
}
function handleLegendData(params) {
  const {
    legendData,
    isSmooth,
    isStep,
    markLine,
    markPoint,
    labelHtml,
    theme,
    seriesData: seriesData2,
    isArea,
    yAxisOption,
    splitLine,
    colors,
    series
  } = params;
  legendData.forEach((legend, index) => {
    const seriesUnit = cloneDeep(seriesInit$6);
    seriesUnit.smooth = isSmooth || false;
    seriesUnit.step = isStep && "end" || false;
    handleMarkLine$1(markLine, seriesUnit);
    handleMarkPoint(markPoint, seriesUnit);
    handleLabel(labelHtml, seriesUnit, theme);
    seriesUnit.name = legend;
    seriesUnit.data = seriesData2[legend];
    handleIsArea({ isArea, markLine, seriesData: seriesData2, legend, yAxisOption, seriesUnit, splitLine, index, colors });
    series.push(seriesUnit);
  });
}
function handleItemStyle(itemStyle) {
  if (itemStyle == null ? void 0 : itemStyle.borderColor) {
    seriesInit$6.itemStyle.normal.borderColor = itemStyle == null ? void 0 : itemStyle.borderColor;
  }
  if (itemStyle == null ? void 0 : itemStyle.symbolSize) {
    seriesInit$6.symbolSize = itemStyle == null ? void 0 : itemStyle.symbolSize;
  }
}
function setSeries$5(params) {
  const {
    seriesData: seriesData2,
    legendData,
    theme,
    isArea,
    isSmooth,
    isStep,
    markLine,
    markPoint,
    splitLine,
    labelHtml,
    yAxisOption,
    itemStyle,
    colors
  } = params;
  switch (theme) {
    case "dark":
      seriesInit$6.itemStyle.normal.borderColor = darkColor;
      break;
    default:
      seriesInit$6.itemStyle.normal.borderColor = lightColor;
      break;
  }
  handleItemStyle(itemStyle);
  const series = [];
  handleLegendData({
    legendData,
    isSmooth,
    isStep,
    markLine,
    markPoint,
    labelHtml,
    theme,
    seriesData: seriesData2,
    isArea,
    yAxisOption,
    splitLine,
    colors,
    series
  });
  if (Array.isArray(yAxisOption)) {
    yAxisOption.forEach((item, index) => {
      series.forEach((items, indexs) => {
        if (item.dataName && item.dataName.includes(items.name)) {
          series[indexs].yAxisIndex = index;
        }
      });
    });
  }
  return series;
}
function handleSplitTopAreaStyleSeries(itemx, percentx, bottomColorx) {
  const seriesObj = {
    type: itemx.type,
    name: itemx.name,
    data: itemx.data,
    smooth: itemx.smooth,
    step: itemx.step,
    symbol: "none",
    areaStyle: {
      color: {
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: [
          {
            color: "rgba(0,0,0,0)",
            offset: 0
          },
          {
            offset: 1 - percentx - 1e-5,
            color: "rgba(0,0,0,0)"
          },
          {
            offset: 1 - percentx,
            color: bottomColorx
          },
          {
            offset: 1,
            color: bottomColorx
          }
        ],
        type: "linear"
      },
      origin: "end"
    },
    lineStyle: {
      width: 0
    }
  };
  return seriesObj;
}
function handleCustomFormatter(params, dataLength) {
  let htmlString = "";
  params.forEach((item, index) => {
    if (index < dataLength) {
      if (index === 0) {
        htmlString += `<div style="margin-bottom:4px;">${item.name}</div>`;
      }
      htmlString += `
                    <div>
                        <span style="display:inline-block;width:10px;
                        height:10px;border-radius:5px;background-color:${item.color};">
                        </span>
                        <span style="margin-left:5px;color:#ffffff">
                            <span style="display:inline-block;
                            margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                                margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                            margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                                margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                            margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                                margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                            margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                                margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                            margin-right:8px;min-width:60px;">${item.seriesName}</span> 
                            <span style="font-weight:bold">${item.value}</span>
                        </span>
                    </div>
                `;
    }
  });
  return htmlString;
}
function setLimitFormatter$1(baseOption) {
  const dataLength = baseOption.legend.data.length;
  const toolTipFormatter = baseOption.tooltip.formatter;
  baseOption.tooltip.formatter = (params, ticket, callback) => {
    if (toolTipFormatter) {
      return toolTipFormatter(params.slice(0, dataLength), ticket, callback);
    } else {
      handleCustomFormatter(params, dataLength);
    }
  };
}
function setBottomAreaStyle(baseOption, iChartOption, YAxiMax) {
  if (iChartOption.area && iChartOption.markLine && iChartOption.markLine.bottom) {
    const temp = [];
    baseOption.series.forEach((item) => {
      const bottomColor = codeToRGB(iChartOption.markLine.bottomColor, 0.3) || "rgba(244,49,70,0.3)";
      const minValue = min(item.data);
      const percent = (iChartOption.markLine.bottom - minValue) / (YAxiMax - minValue);
      if (iChartOption.markLine.bottom >= minValue) {
        const newSeries = handleSplitTopAreaStyleSeries(item, percent, bottomColor);
        temp.push(newSeries);
      }
    });
    baseOption.series = baseOption.series.concat(temp);
    setLimitFormatter$1(baseOption);
  }
}
function handleSplitBottomAreaStyleSeries(item, percent, colorTo, colorFrom) {
  const newSeries = {
    type: item.type,
    name: item.name,
    data: item.data,
    smooth: item.smooth,
    step: item.step,
    lineStyle: {
      width: 0
    },
    symbol: "none",
    areaStyle: {
      origin: "end",
      color: {
        type: "linear",
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: [
          {
            offset: 0,
            color: "rgba(0,0,0,0)"
          },
          {
            offset: 1 - percent - 1e-5,
            color: "rgba(0,0,0,0)"
          },
          {
            offset: 1 - percent,
            color: colorTo
          },
          {
            offset: 1,
            color: colorFrom
          }
        ]
      }
    }
  };
  return newSeries;
}
function setSplitBottomAreaStyle(baseOption, iChartOption, YAxiMax) {
  if (iChartOption.area && iChartOption.splitLine) {
    const temp = [];
    const colors = baseOption.color;
    baseOption.series.forEach((item, index) => {
      const minValue = min(item.data);
      const percent = (iChartOption.splitLine - minValue) / (YAxiMax - minValue);
      const color2 = getColor(colors, index);
      const colorFrom = codeToRGB(color2, 0.25);
      const colorTo = codeToRGB(color2, 0.1);
      const newSeries = handleSplitBottomAreaStyleSeries(item, percent, colorTo, colorFrom);
      temp.push(newSeries);
    });
    baseOption.series = baseOption.series.concat(temp);
    setLimitFormatter$1(baseOption);
  }
}
const darkXaxis = {
  type: "category",
  boundaryGap: true,
  data: [],
  splitLine: {
    show: false
  },
  axisLine: {
    lineStyle: {
      width: 2,
      color: darkAxis
    }
  },
  axisTick: {
    alignWithLabel: true,
    lineStyle: {
      width: 2,
      color: darkAxis
    }
  },
  axisLabel: {
    color: darkAxisLabel
  }
};
const lightXaxis = {
  type: "category",
  boundaryGap: true,
  data: [],
  splitLine: {
    show: false
  },
  axisLine: {
    lineStyle: {
      width: 2,
      color: lightAxis
    }
  },
  axisTick: {
    alignWithLabel: true,
    lineStyle: {
      width: 2,
      color: lightAxis
    }
  },
  axisLabel: {
    color: lightAxisLabel
  }
};
const darkYaxis = {
  type: "value",
  axisLine: {
    show: false
  },
  axisTick: {
    show: false
  },
  axisLabel: {
    color: darkAxisLabel
  },
  nameTextStyle: {
    color: darkAxisLabel,
    fontSize: 12
  },
  splitLine: {
    show: true,
    lineStyle: {
      color: [darkAxis],
      width: 2,
      type: "solid"
    }
  }
};
const lightYaxis = {
  type: "value",
  axisLine: {
    show: false
  },
  axisTick: {
    show: false
  },
  axisLabel: {
    color: lightAxisLabel
  },
  nameTextStyle: {
    color: lightAxisLabel,
    fontSize: 12
  },
  splitLine: {
    show: true,
    lineStyle: {
      color: [lightAxis],
      width: 2,
      type: "solid"
    }
  }
};
const yAxisNameDefault = {
  text: "",
  textStyle: {
    color: darkAxisLabel,
    fontWeight: "normal",
    fontSize: 12,
    lineHeight: 12
  },
  padding: [0, 0, 0, 0]
};
const lightTooltip = {
  trigger: "axis",
  axisPointer: {
    type: "line",
    lineStyle: {
      width: 1,
      type: "soild",
      color: "rgba(210,210,210,1)"
    },
    shadowStyle: {
      color: "rgba(210,210,210,1)"
    }
  },
  borderWidth: 0,
  backgroundColor: "#ffffff",
  textStyle: {
    color: lightFontColor,
    fontSize: 14
  },
  formatter: void 0
};
const darkTooltip = {
  trigger: "axis",
  axisPointer: {
    type: "line",
    lineStyle: {
      width: 1,
      type: "soild",
      color: "rgba(238,238,238,0.3)"
    },
    shadowStyle: {
      color: "rgba(210,210,210,0.2)"
    }
  },
  padding: [14, 16],
  borderWidth: 0,
  backgroundColor: "#393939",
  textStyle: {
    color: darkFontColor,
    fontSize: 14
  },
  formatter: void 0
};
const lightLegend = {
  data: [],
  icon: "circle",
  left: "center",
  bottom: 12,
  itemGap: 28,
  inactiveColor: lightAxis,
  inactiveBorderColor: lightColor,
  inactiveBorderWidth: 0,
  formatter: (name) => {
    return [`{a|${name}}`];
  },
  textStyle: {
    rich: {
      a: {
        fontSize: 12,
        color: lightAxisLabel,
        align: "left",
        verticalAlign: "top",
        padding: [4, 0, 0, 0]
      }
    }
  }
};
const darkLegend = {
  data: [],
  icon: "circle",
  left: "center",
  bottom: 12,
  itemGap: 28,
  inactiveColor: darkAxis,
  inactiveBorderColor: darkColor,
  inactiveBorderWidth: 0,
  formatter: (name) => {
    return [`{a|${name}}`];
  },
  textStyle: {
    rich: {
      a: {
        fontSize: 12,
        color: darkAxisLabel,
        align: "left",
        verticalAlign: "top",
        padding: [4, 0, 0, 0]
      }
    }
  }
};
const dataZoomBackgroundColor = "#000000";
const handleColor$1 = "#ffffff";
const handleBorderColor = "#393939";
const handleHoverColor = "#ffffff";
const handleHoverBorderColor = "#4e4e4e";
const dataBackgroundColor = "#303030";
const selectedDataBackgroundColor = "#474747";
const middleHandleColor = "rgba(255,255,255,0)";
const handleShadowColor = "rgba(25, 25, 25, 0.5)";
const dataLineColor = "rgba(57, 57, 57,0.6)";
const selectedDataLineColor = "rgba(57, 57, 57,1)";
const lightDataZoom = [
  {
    borderColor: "none",
    type: "slider",
    zoomLock: false,
    show: true,
    height: 24,
    left: "center",
    bottom: 18,
    xAxisIndex: [0],
    end: 100,
    start: 0,
    backgroundColor: "#f9f9f9",
    fillerColor: middleHandleColor,
    handleSize: "85%",
    handleIcon: "path://M0 0.2 Q 0 0 0.2 0 L0.8 0 Q1 0 1 0.2 L1 2.8 Q1 3 0.8 3L0.2 3 Q0 3 0 2.8 Z",
    handleStyle: {
      color: darkColor,
      shadowBlur: 10,
      shadowColor: "rgba(25, 25, 25, 0.3)",
      shadowOffsetX: 0,
      shadowOffsetY: 0,
      opacity: 1,
      borderColor: lightColor,
      borderWidth: 5,
      borderJoin: "round"
    },
    dataBackground: {
      lineStyle: {
        color: "#f9f9f9",
        join: "round",
        cap: "round"
      },
      areaStyle: {
        opacity: 1,
        color: "#eaeaea"
      }
    },
    selectedDataBackground: {
      lineStyle: {
        color: "#f9f9f9"
      },
      areaStyle: {
        opacity: 0.9,
        color: "#bbbbbb"
      }
    },
    moveHandleSize: "0",
    emphasis: {
      handleStyle: {
        color: "#191919",
        borderColor: lightColor
      }
    }
  },
  {
    xAxisIndex: [0],
    end: 100,
    start: 0,
    type: "inside"
  }
];
const darkDataZoom = [
  {
    type: "slider",
    show: true,
    height: 24,
    bottom: 18,
    left: "center",
    start: 0,
    end: 100,
    zoomLock: false,
    xAxisIndex: [0],
    borderColor: "none",
    backgroundColor: dataZoomBackgroundColor,
    fillerColor: middleHandleColor,
    handleSize: "85%",
    handleIcon: "path://M0 0.2 Q 0 0 0.2 0 L0.8 0 Q1 0 1 0.2 L1 2.8 Q1 3 0.8 3L0.2 3 Q0 3 0 2.8 Z",
    handleStyle: {
      color: handleColor$1,
      shadowBlur: 16,
      shadowColor: handleShadowColor,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
      opacity: 1,
      borderColor: handleBorderColor,
      borderWidth: 5,
      borderJoin: "round"
    },
    dataBackground: {
      lineStyle: {
        color: dataLineColor,
        join: "round",
        cap: "round"
      },
      areaStyle: {
        opacity: 0.8,
        color: dataBackgroundColor
      }
    },
    selectedDataBackground: {
      lineStyle: {
        color: selectedDataLineColor
      },
      areaStyle: {
        opacity: 0.9,
        color: selectedDataBackgroundColor
      }
    },
    emphasis: {
      handleStyle: {
        color: handleHoverColor,
        borderColor: handleHoverBorderColor
      }
    },
    moveHandleSize: "0"
  },
  {
    type: "inside",
    xAxisIndex: [0],
    start: 0,
    end: 100
  }
];
function setXAxis$4(theme, xAxisInterval, xAxisFullGrid) {
  let xAxis = {};
  switch (theme) {
    case "dark":
      xAxis = cloneDeep(darkXaxis);
      break;
    default:
      xAxis = cloneDeep(lightXaxis);
      break;
  }
  if (xAxisInterval !== void 0) {
    xAxis.axisLabel.interval = xAxisInterval;
  }
  if (xAxisFullGrid) {
    xAxis.boundaryGap = false;
  }
  return xAxis;
}
function setYAxis$4(theme, yAxisOption) {
  if (!isArray(yAxisOption)) {
    yAxisOption = [yAxisOption];
  }
  const result = [];
  yAxisOption.forEach((item) => {
    let yAxis = {};
    switch (theme) {
      case "dark":
        yAxis = cloneDeep(darkYaxis);
        break;
      default:
        yAxis = cloneDeep(lightYaxis);
        break;
    }
    if (item && item.unit) {
      yAxis.axisLabel.formatter = `{value} ${item.unit}`;
      delete item.unit;
    }
    if (item && item.formatter) {
      yAxis.axisLabel.formatter = item.formatter;
    }
    if (item && item.name) {
      item.nameTextStyle = Object.assign(yAxis.nameTextStyle, item.nameTextStyle);
    }
    result.push(Object.assign(yAxis, item));
  });
  return result;
}
function setYAxisName$4(theme, name, chartPadding) {
  if (name) {
    const lineYAxisName = cloneDeep(yAxisNameDefault);
    lineYAxisName.text = name;
    lineYAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
    lineYAxisName.padding[0] = chartPadding[0] - 30;
    lineYAxisName.padding[3] = chartPadding[3];
    return lineYAxisName;
  }
  return {};
}
function setTooltip$b(theme, formatter) {
  let LineTooltip = {};
  switch (theme) {
    case "dark":
      LineTooltip = cloneDeep(darkTooltip);
      break;
    default:
      LineTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    LineTooltip.formatter = formatter;
  }
  return LineTooltip;
}
function setLegend$6(theme, selfLegend) {
  const { show: show2, position, orient: orient2, data: data2, itemHeight, icon, itemWidth } = selfLegend;
  let LineLegend = {};
  switch (theme) {
    case "dark":
      LineLegend = cloneDeep(darkLegend);
      break;
    default:
      LineLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    LineLegend.show = false;
  }
  if (orient2) {
    LineLegend.orient = orient2;
  }
  LineLegend.top = position.top || "auto";
  LineLegend.left = position.left || "auto";
  LineLegend.right = position.right || "auto";
  LineLegend.bottom = position.bottom || "auto";
  LineLegend.data = data2;
  LineLegend.itemWidth = itemWidth || 25;
  if (data2) {
    LineLegend.itemHeight = itemHeight || 4;
  } else {
    LineLegend.icon = icon || "circle";
    LineLegend.itemHeight = itemHeight || 14;
  }
  return LineLegend;
}
function setDataZoom$1(theme, selfDataZoom) {
  const { show: show2, position, start, end } = selfDataZoom;
  let LineDataZoom = [];
  if (show2) {
    switch (theme) {
      case "dark":
        LineDataZoom = cloneDeep(darkDataZoom);
        break;
      default:
        LineDataZoom = cloneDeep(lightDataZoom);
        break;
    }
    start && (LineDataZoom[0].start = start);
    end && (LineDataZoom[0].end = end);
    LineDataZoom[0].top = position.top || "auto";
    LineDataZoom[0].left = position.left || "auto";
    LineDataZoom[0].right = position.right || "auto";
    LineDataZoom[0].bottom = position.bottom || "auto";
  }
  return LineDataZoom;
}
function legendChange(chartInstance, baseOpt, iChartOption) {
  const data2 = cloneDeep(iChartOption.legend.data);
  chartInstance.on("legendselectchanged", function(params) {
    if (!params.selected[params.name]) {
      baseOpt.legend.data.forEach((item) => {
        if (item.name === params.name) {
          item.icon = item.iconChange;
        }
      });
      chartInstance.setOption(baseOpt);
    } else {
      baseOpt.legend.data.forEach((item) => {
        if (item.name === params.name) {
          data2.forEach((itemd) => {
            if (itemd.name === item.name) {
              item.icon = itemd.icon;
            }
          });
        }
      });
      chartInstance.setOption(baseOpt);
    }
  });
}
function handleVisualMapItem({ index, topColor, top: top2, bottom: bottom2, colors, bottomColor, vmColor }) {
  const visualMapItem = {
    show: false,
    type: "piecewise",
    dimension: 1,
    seriesIndex: index,
    pieces: [
      {
        gte: top2,
        color: topColor
      },
      {
        gt: bottom2,
        lt: top2,
        color: getColor(colors, index)
      },
      {
        lte: bottom2,
        color: bottomColor
      }
    ],
    outOfRange: {
      color: vmColor
    }
  };
  return visualMapItem;
}
function setVisualMap$2(legendData, seriesData2, markLine, colors) {
  const visualMap = [];
  if (markLine) {
    const topValue = markLine.top;
    const bottomValue = markLine.bottom;
    const vmColor = "#f43146";
    const topColor = markLine.topColor || vmColor;
    const bottomColor = markLine.bottomColor || vmColor;
    if (topValue == void 0 && bottomValue == void 0) {
      return visualMap;
    }
    if (topValue !== void 0 && bottomValue !== void 0 && bottomValue >= topValue) {
      throw new Error("\u9608\u503C\u7EBFbottom\u7684\u503C\u5FC5\u987B\u5C0F\u4E8E\u9608\u503C\u7EBFtop\u7684\u503C");
    }
    legendData.forEach((legendName, index) => {
      const data2 = seriesData2[legendName];
      const minData = min(data2);
      const maxData = max(data2);
      let bottom2 = bottomValue;
      let top2 = topValue;
      if (bottomValue == void 0) {
        bottom2 = Math.min(top2 - 1, minData - 1);
      }
      if (topValue == void 0) {
        top2 = Math.max(bottom2 + 1, maxData + 1);
      }
      const visualMapItem = handleVisualMapItem({ index, topColor, top: top2, bottom: bottom2, colors, bottomColor, vmColor });
      visualMap.push(visualMapItem);
    });
  }
  return visualMap;
}
function setDashedLineVisualMap(seriesIndex, lineColor, predictIndex) {
  const vm = {
    type: "piecewise",
    seriesIndex,
    dimension: 0,
    show: false,
    pieces: [
      {
        gte: 0,
        lte: predictIndex,
        color: "rgba(0,0,0,0)"
      },
      {
        gt: predictIndex,
        color: lineColor
      }
    ]
  };
  return vm;
}
function setToolTip$1(dataLength, theme, selfFormatter) {
  if (selfFormatter) {
    return selfFormatter;
  }
  const tipHtml = (params) => {
    let htmlString = "";
    params.forEach((item, index) => {
      if (index < dataLength) {
        if (index === 0) {
          htmlString += `${item.name}<br/>`;
        }
        htmlString += `
                    <div>
                        <span style="display:inline-block;width:10px;
                        height:10px;border-radius:5px;background-color:${item.color};">
                        </span>
                        <span style="margin-left:5px;color:${theme == "dark" ? darkFontColor : lightFontColor}">
                            <span style="display:inline-block;width:80px;">${item.seriesName}</span> 
                            <span style="font-weight:bold">${item.value}</span>
                        </span>
                    </div>
                `;
      }
    });
    return htmlString;
  };
  return tipHtml;
}
function handlePredict(option, theme, predict, tipHtml, lineStyle2) {
  if (predict) {
    const data2 = option.series;
    const dataLength = data2.length;
    option.xAxis.data.length;
    const predictIndex = option.xAxis.data.indexOf(predict);
    for (let index = 0; index < dataLength; index++) {
      const temp = cloneDeep(data2[index]);
      temp.lineStyle = {
        width: 3,
        type: [5, 8]
      };
      temp.itemStyle = {
        opacity: 0
      };
      temp.silent = true;
      temp.showSymbol = false;
      temp.showAllSymbol = false;
      option.series.push(temp);
      let dashColor = theme == "dark" ? darkColor : lightColor;
      if (lineStyle2 && lineStyle2.dashColor) {
        dashColor = lineStyle2.dashColor;
      }
      option.visualMap.push(setDashedLineVisualMap(dataLength + index, dashColor, predictIndex));
    }
    option.tooltip.formatter = setToolTip$1(dataLength, theme, tipHtml);
  }
}
function handleUpdateData(baseOptt, iChartOption, theme, xAxisKey) {
  baseOptt.color = iChartOption.color;
  baseOptt.xAxis = setXAxis$4(theme, iChartOption.xAxisInterval, iChartOption.xAxisFullGrid);
  baseOptt.yAxis = setYAxis$4(theme, iChartOption.yAxis);
  baseOptt.title = setYAxisName$4(theme, iChartOption.yAxisName, iChartOption.chartPadding);
  baseOptt.tooltip = setTooltip$b(theme, iChartOption.tipHtml);
  baseOptt.legend = setLegend$6(theme, iChartOption.legend);
  const legendData = getLegendData$2(iChartOption.data, xAxisKey);
  const xAxisData = getXAxisData$1(iChartOption.data, xAxisKey);
  const seriesData2 = getSeriesData(iChartOption.data, legendData);
  return { baseOptt, legendData, xAxisData, seriesData: seriesData2 };
}
class LineChart {
  constructor(iChartOption, plugins, chartInstance) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption(chartInstance, this.baseOption);
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption(chartInstance, baseOpt) {
    legendChange(chartInstance, baseOpt, this.iChartOption);
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    const xAxisKey = iChartOption.xAxis;
    const { baseOptt, legendData, xAxisData, seriesData: seriesData2 } = handleUpdateData(this.baseOption, iChartOption, theme, xAxisKey);
    this.baseOption = baseOptt;
    if (!this.baseOption.legend.data) {
      this.baseOption.legend.data = legendData;
    }
    this.baseOption.xAxis.data = xAxisData;
    this.baseOption.series = setSeries$5({
      seriesData: seriesData2,
      legendData,
      theme,
      isArea: iChartOption.area,
      isSmooth: iChartOption.smooth,
      isStep: iChartOption.step,
      markLine: iChartOption.markLine,
      markPoint: iChartOption.markPoint,
      splitLine: iChartOption.splitLine,
      labelHtml: iChartOption.labelHtml,
      yAxisOption: iChartOption.yAxis,
      itemStyle: iChartOption.itemStyle,
      colors: this.baseOption.color
    });
    this.baseOption.dataZoom = setDataZoom$1(theme, iChartOption.dataZoom);
    this.baseOption.visualMap = setVisualMap$2(legendData, seriesData2, iChartOption.markLine, iChartOption.color);
    this.baseOption.grid.top = iChartOption.chartPadding[0];
    this.baseOption.grid.right = iChartOption.chartPadding[1];
    this.baseOption.grid.bottom = iChartOption.chartPadding[2];
    this.baseOption.grid.left = iChartOption.chartPadding[3];
    handlePredict(this.baseOption, iChartOption.theme, iChartOption.predict, iChartOption.tipHtml, iChartOption.lineStyle);
    const echartsOption = iChartOption.echartsOption;
    if (echartsOption) {
      const opt = Object.keys(echartsOption);
      for (let i = 0; i < opt.length; i++) {
        this.baseOption[opt[i]] = Object.assign(this.baseOption[opt[i]], echartsOption[opt[i]]);
      }
    }
  }
  secondaryUpdateOption(YAxiMax, YAxiMin) {
    if (this.iChartOption.area && this.iChartOption.markLine && this.iChartOption.markLine.bottom) {
      setBottomAreaStyle(this.baseOption, this.iChartOption, YAxiMax);
    } else if (this.iChartOption.area && this.iChartOption.splitLine) {
      setSplitBottomAreaStyle(this.baseOption, this.iChartOption, YAxiMax);
    }
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const seriesInit$5 = {
  label: {
    show: false,
    color: "#eeeeee",
    fontSize: 12
  },
  data: [],
  type: "bar",
  barWidth: 8,
  barGap: "60%",
  markLine: null,
  markPoint: null,
  itemStyle: {
    borderRadius: [5, 5, 0, 0]
  }
};
function handlePosition(direction, itemStyle) {
  if (direction && direction === "horizontal") {
    seriesInit$5.itemStyle.borderRadius = [0, 5, 5, 0];
  }
  if (itemStyle == null ? void 0 : itemStyle.barWidth) {
    seriesInit$5.barWidth = itemStyle == null ? void 0 : itemStyle.barWidth;
  }
  if (itemStyle == null ? void 0 : itemStyle.barGap) {
    seriesInit$5.barGap = itemStyle == null ? void 0 : itemStyle.barGap;
  }
  if (itemStyle == null ? void 0 : itemStyle.color) {
    seriesInit$5.itemStyle.color = itemStyle == null ? void 0 : itemStyle.color;
  }
}
function handleMarkLine(markLine, seriesUnit, direction) {
  if (markLine) {
    seriesUnit.markLine = cloneDeep(markLineDefault);
    if (direction && direction === "horizontal") {
      if (markLine.top) {
        seriesUnit.markLine.data.push({ xAxis: markLine.top });
      }
      if (markLine.bottom) {
        seriesUnit.markLine.data.push({ xAxis: markLine.bottom });
      }
    } else {
      if (markLine.top) {
        seriesUnit.markLine.data.push({ yAxis: markLine.top });
      }
      if (markLine.bottom) {
        seriesUnit.markLine.data.push({ yAxis: markLine.bottom });
      }
    }
  }
}
function handleStack(type, seriesUnit, index, legendData) {
  if (type && type === "stack") {
    seriesUnit.stack = "stack";
    if (index !== legendData.length - 1) {
      delete seriesUnit.itemStyle.borderRadius;
    }
  }
}
function handleBothSides(type, seriesUnit, direction, index, legendData) {
  if (type && type === "both-sides") {
    seriesUnit.stack = "stack";
    if (direction && direction === "horizontal") {
      if (index == 0) {
        seriesUnit.itemStyle.borderRadius = [0, 5, 5, 0];
      }
      if (index == legendData.length - 1) {
        seriesUnit.itemStyle.borderRadius = [5, 0, 0, 5];
      }
    } else {
      if (index == 0) {
        seriesUnit.itemStyle.borderRadius = [5, 5, 0, 0];
      }
      if (index == legendData.length - 1) {
        seriesUnit.itemStyle.borderRadius = [0, 0, 5, 5];
      }
    }
  }
}
function handleWaterFall(type, seriesUnit) {
  if (type && type === "water-fall") {
    seriesUnit.itemStyle.borderRadius = [5, 5, 5, 5];
    seriesUnit.data.push(seriesUnit.data.reduce(function(prev, curr) {
      const n = Number(curr) || 0;
      return prev + n;
    }, 0));
  }
}
function handleRange(type, seriesUnit) {
  if (type && type === "range") {
    seriesUnit.itemStyle.borderRadius = [5, 5, 5, 5];
  }
}
function setSeries$4(seriesData2, legendData, theme, iChartOption) {
  const { type, direction, label: label2, markLine, itemStyle } = iChartOption;
  handlePosition(direction, itemStyle);
  const series = [];
  legendData.forEach((legend, index) => {
    const seriesUnit = cloneDeep(seriesInit$5);
    let labelOption;
    if (label2 && isArray(label2)) {
      labelOption = label2[index];
    } else {
      labelOption = label2;
    }
    if (labelOption && labelOption.show) {
      seriesUnit.label.show = true;
      seriesUnit.label.offset = labelOption.offset || [0, 0];
      seriesUnit.label.position = labelOption.position || "inside";
      seriesUnit.label.formatter = labelOption.formatter;
    }
    handleMarkLine(markLine, seriesUnit, direction);
    seriesUnit.name = legend;
    seriesUnit.data = seriesData2[legend];
    handleStack(type, seriesUnit, index, legendData);
    handleBothSides(type, seriesUnit, direction, index, legendData);
    handleWaterFall(type, seriesUnit);
    handleRange(type, seriesUnit);
    series.push(seriesUnit);
  });
  if (Array.isArray(iChartOption.yAxis)) {
    iChartOption.yAxis.forEach((item, index) => {
      series.forEach((items, indexs) => {
        if (item.dataName && item.dataName.includes(items.name)) {
          series[indexs].yAxisIndex = index;
        }
      });
    });
  }
  return series;
}
function handleColorStops(percent, originColor) {
  const colorStops = [
    {
      offset: 0,
      color: "#F43146"
    },
    {
      offset: percent,
      color: "#F43146"
    },
    {
      offset: percent + 1e-3,
      color: originColor
    },
    {
      offset: 1,
      color: originColor
    }
  ];
  return colorStops;
}
function handleTopObj(d, direction, percent, originColor) {
  const topObj = {
    value: d,
    itemStyle: {
      color: {
        type: "linear",
        x: direction === "horizontal" ? 1 : 0,
        y: direction === "horizontal" ? 0 : 0,
        x2: direction === "horizontal" ? 0 : 0,
        y2: direction === "horizontal" ? 0 : 1,
        colorStops: handleColorStops(percent, originColor)
      }
    }
  };
  return topObj;
}
function handleBottomObj(d, direction, percent, originColor) {
  const bottomObj = {
    value: d,
    itemStyle: {
      color: {
        type: "linear",
        x: direction === "horizontal" ? 0 : 0,
        y: direction === "horizontal" ? 0 : 1,
        x2: direction === "horizontal" ? 1 : 0,
        y2: direction === "horizontal" ? 0 : 0,
        colorStops: handleColorStops(percent, originColor)
      }
    }
  };
  return bottomObj;
}
const colorStopsOrigin = [
  { offset: 0, color: "#F43146" },
  { offset: 1, color: "#F43146" }
];
function handleColorStopsTop(originColor, bottomPercent) {
  const colorStops = [
    { offset: 0, color: originColor },
    { offset: bottomPercent, color: originColor },
    { offset: bottomPercent + 1e-4, color: "#F43146" },
    { offset: 1, color: "#F43146" }
  ];
  return colorStops;
}
function handleColorStopsBottom(originColor, topPercent) {
  const colorStops = [
    { offset: 0, color: "#F43146" },
    { offset: topPercent, color: "#F43146" },
    { offset: topPercent + 1e-4, color: originColor },
    { offset: 1, color: originColor }
  ];
  return colorStops;
}
function handleColorStopsOther(originColor, topPercent, bottomPercent) {
  const colorStops = [
    { offset: 0, color: "#F43146" },
    { offset: topPercent, color: "#F43146" },
    { offset: topPercent + 1e-4, color: originColor },
    { offset: bottomPercent, color: originColor },
    { offset: bottomPercent + 1e-4, color: "#F43146" },
    { offset: 1, color: "#F43146" }
  ];
  return colorStops;
}
function handleResObj$1(d, direction, colorStops) {
  const resObj = {
    value: d,
    itemStyle: {
      color: {
        type: "linear",
        x: direction === "horizontal" ? 1 : 0,
        y: direction === "horizontal" ? 0 : 0,
        x2: direction === "horizontal" ? 0 : 0,
        y2: direction === "horizontal" ? 0 : 1,
        colorStops
      }
    }
  };
  return resObj;
}
function handleSeries$3(iChartOption, baseOption, exclude, colors, direction) {
  let top2 = iChartOption.markLine.top;
  let bottom2 = iChartOption.markLine.bottom;
  const usefullSeries = baseOption.series.filter((item) => {
    return exclude.indexOf(item.name) == -1;
  });
  usefullSeries.forEach((item, index) => {
    if (exclude.indexOf(item.name) == -1) {
      const barData = item.data;
      const placeHolderData = baseOption.series[index * 2].data;
      item.data = barData.map((d, i) => {
        const pd = placeHolderData[i];
        if (top2 == void 0) {
          top2 = pd + d + 1;
        }
        if (bottom2 == void 0) {
          bottom2 = pd - 1;
        }
        const originColor = getColor(colors, index);
        let topPercent = 0;
        let bottomPercent = 1;
        topPercent = (d + pd - top2) / d;
        topPercent < 0 && (topPercent = 0);
        topPercent > 1 && (topPercent = 1);
        bottomPercent = (d + pd - bottom2) / d;
        bottomPercent < 0 && (bottomPercent = 0);
        bottomPercent > 1 && (bottomPercent = 1);
        let colorStops = [];
        if (topPercent == 1 || bottomPercent == 0) {
          colorStops = colorStopsOrigin;
        } else if (topPercent == 0 && bottomPercent == 1) {
          return d;
        } else if (topPercent == 0) {
          colorStops = handleColorStopsTop(originColor, bottomPercent);
        } else if (bottomPercent == 1) {
          colorStops = handleColorStopsBottom(originColor, topPercent);
        } else {
          colorStops = handleColorStopsOther(originColor, topPercent, bottomPercent);
        }
        const resObj = handleResObj$1(d, direction, colorStops);
        return resObj;
      });
    }
  });
}
function setMarkLine$3(baseOption, iChartOption) {
  const type = iChartOption.type;
  const colors = baseOption.color;
  const direction = iChartOption.direction;
  const exclude = ["Placeholder"];
  if (iChartOption.markLine && type !== "water-fall" && type !== "range") {
    const top2 = iChartOption.markLine.top;
    const bottom2 = iChartOption.markLine.bottom;
    const usefullSeries = baseOption.series.filter((item) => {
      return exclude.indexOf(item.name) == -1;
    });
    usefullSeries.forEach((item, index) => {
      if (exclude.indexOf(item.name) == -1) {
        const barData = item.data;
        item.data = barData.map((d) => {
          const originColor = getColor(colors, index);
          if (top2 && d >= 0 && top2 >= 0 && d > top2) {
            const percent = (d - top2) / (d - 0);
            const topObj = handleTopObj(d, direction, percent, originColor);
            return topObj;
          } else if (bottom2 && d <= 0 && bottom2 <= 0 && d < bottom2) {
            const percent = (bottom2 - d) / (0 - d);
            const bottomObj = handleBottomObj(d, direction, percent, originColor);
            return bottomObj;
          } else {
            return d;
          }
        });
      }
    });
  }
  if (iChartOption.markLine && type == "range") {
    handleSeries$3(iChartOption, baseOption, exclude, colors, direction);
  }
}
function placeFun(index, placeholderData) {
  const a = {
    name: "Placeholder",
    type: "bar",
    stack: `stack${index}`,
    itemStyle: {
      borderColor: "transparent",
      color: "transparent"
    },
    emphasis: {
      itemStyle: {
        borderColor: "transparent",
        color: "transparent"
      }
    },
    data: placeholderData
  };
  return a;
}
function setRange(baseOption, iChartOption) {
  const type = iChartOption.type;
  if (type && type === "range") {
    const tempArray = [];
    baseOption.series.forEach((item, index) => {
      const barData = item.data;
      const barRealData = [];
      const placeholderData = [];
      const placeholder = placeFun(index, placeholderData);
      barData.forEach((d) => {
        placeholderData.push(d[0]);
        barRealData.push(d[1] - d[0]);
      });
      item.stack = `stack${index}`;
      item.data = barRealData;
      tempArray.push(placeholder);
      tempArray.push(item);
    });
    baseOption.series = tempArray;
  }
}
function setWaterFall(baseOption, iChartOption) {
  const type = iChartOption.type;
  if (type && type === "water-fall") {
    baseOption.xAxis.data.push("Total");
    const tempArray = [];
    baseOption.series.forEach((item, index) => {
      const barData = item.data;
      const placeholderData = [0];
      const placeholder = placeFun(index, placeholderData);
      barData.forEach((d, i) => {
        if (i < barData.length - 1) {
          placeholderData.push((Number(d) || 0) + placeholderData[i]);
        }
      });
      placeholderData[placeholderData.length - 1] = 0;
      item.stack = `stack${index}`;
      tempArray.push(placeholder);
      tempArray.push(item);
    });
    baseOption.series = tempArray;
  }
}
function setLimitFormatter(baseOption, iChartOption) {
  const type = iChartOption.type;
  const toolTipFormatter = baseOption.tooltip.formatter;
  const exclude = ["Placeholder"];
  const colors = baseOption.color;
  baseOption.tooltip.formatter = (params, ticket, callback) => {
    const newParams = params.filter((item) => {
      return exclude.indexOf(item.seriesName) == -1;
    });
    if (toolTipFormatter) {
      return toolTipFormatter(newParams, ticket, callback);
    }
    let htmlString = "";
    newParams.forEach((item, index) => {
      if (index === 0) {
        htmlString += `<div style="margin-bottom:4px;">${item.name}</div>`;
      }
      const itemColor = typeof item.color == "string" ? item.color : getColor(colors, index);
      htmlString += `
                    <div>
                        <span style="display:inline-block;width:10px;height
                        :10px;border-radius:5px;background-color:${itemColor};">
                        </span>
                        <span style="margin-left:5px;">
                            <span style="display:inline-block;margin-right:8px;min-width:60px;">
                            ${item.seriesName}</span> 
  <span style="font-weight:bold">
    ${type === "range" ? `${`${`[${params[index * 2].value}`}-${params[index * 2].value + item.value}`}]` : item.value}</span>
                        </span>
                    </div>
                `;
    });
    return htmlString;
  };
}
function setXAxis$3(theme, xAxisInterval) {
  let barXAxis = {};
  switch (theme) {
    case "dark":
      barXAxis = cloneDeep(darkXaxis);
      break;
    default:
      barXAxis = cloneDeep(lightXaxis);
      break;
  }
  if (xAxisInterval !== void 0) {
    barXAxis.axisLabel.interval = xAxisInterval;
  }
  return barXAxis;
}
function setYAxis$3(theme, yAxisOption) {
  if (isArray(yAxisOption)) {
    const result = [];
    yAxisOption.forEach((item) => {
      let yAxis = {};
      switch (theme) {
        case "dark":
          yAxis = cloneDeep(darkYaxis);
          break;
        default:
          yAxis = cloneDeep(lightYaxis);
          break;
      }
      if (item && item.unit) {
        yAxis.axisLabel.formatter = `{value} ${item.unit}`;
        delete item.unit;
      }
      if (item && item.formatter) {
        yAxis.axisLabel.formatter = item.formatter;
      }
      if (item && item.name) {
        item.nameTextStyle = Object.assign(yAxis.nameTextStyle, item.nameTextStyle);
      }
      result.push(Object.assign(yAxis, item));
    });
    return result;
  } else {
    let yAxis = {};
    switch (theme) {
      case "dark":
        yAxis = cloneDeep(darkYaxis);
        break;
      default:
        yAxis = cloneDeep(lightYaxis);
        break;
    }
    return Object.assign(yAxis, yAxisOption);
  }
}
function setYAxisName$3(theme, name, chartPadding, direction) {
  if (name) {
    if (direction && direction === "horizontal") {
      const yAxisName = cloneDeep(yAxisNameDefault);
      yAxisName.text = name;
      yAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
      const nameLength = getTextWidth(name, 12);
      yAxisName.right = chartPadding[1] - nameLength - 24;
      yAxisName.bottom = chartPadding[2];
      yAxisName.textAlign = "left";
      return yAxisName;
    } else {
      const yAxisName = cloneDeep(yAxisNameDefault);
      yAxisName.text = name;
      yAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
      yAxisName.padding[0] = chartPadding[0] - 30;
      yAxisName.padding[3] = chartPadding[3];
      return yAxisName;
    }
  }
  return {};
}
function setTooltip$a(theme, formatter) {
  let BarTooltip = {};
  switch (theme) {
    case "dark":
      BarTooltip = cloneDeep(darkTooltip);
      break;
    default:
      BarTooltip = cloneDeep(lightTooltip);
      break;
  }
  BarTooltip.axisPointer = {
    type: "shadow",
    shadowStyle: {
      color: theme == "dark" ? "rgba(238,238,238,0.08)" : "rgba(25,25,25,0.08)"
    }
  };
  if (formatter) {
    BarTooltip.formatter = formatter;
  }
  return BarTooltip;
}
function setLegend$5(theme, selfLegend) {
  const { show: show2, position, orient: orient2 } = selfLegend;
  let BarLegend = {};
  switch (theme) {
    case "dark":
      BarLegend = cloneDeep(darkLegend);
      break;
    default:
      BarLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    BarLegend.show = false;
  }
  if (orient2) {
    BarLegend.orient = orient2;
  }
  BarLegend.itemWidth = 12;
  BarLegend.itemHeight = 12;
  BarLegend.top = position.top || "auto";
  BarLegend.left = position.left || "auto";
  BarLegend.right = position.right || "auto";
  BarLegend.bottom = position.bottom || "auto";
  return BarLegend;
}
function setDataZoom(theme, selfDataZoom) {
  const { show: show2, position, start, end } = selfDataZoom;
  let BarDataZoom = [];
  if (show2) {
    switch (theme) {
      case "dark":
        BarDataZoom = cloneDeep(darkDataZoom);
        break;
      default:
        BarDataZoom = cloneDeep(lightDataZoom);
        break;
    }
    start && (BarDataZoom[0].start = start);
    end && (BarDataZoom[0].end = end);
    BarDataZoom[0].top = position.top || "auto";
    BarDataZoom[0].left = position.left || "auto";
    BarDataZoom[0].right = position.right || "auto";
    BarDataZoom[0].bottom = position.bottom || "auto";
  }
  return BarDataZoom;
}
function setDirection$1(baseOption, direction) {
  if (direction && direction === "horizontal") {
    const temp = baseOption.xAxis;
    baseOption.xAxis = baseOption.yAxis;
    baseOption.yAxis = temp;
  }
}
class BarChart$1 {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    const xAxisKey = iChartOption.xAxis;
    this.baseOption.color = iChartOption.color;
    this.baseOption.xAxis = setXAxis$3(theme, iChartOption.xAxisInterval);
    this.baseOption.yAxis = setYAxis$3(theme, iChartOption.yAxis);
    this.baseOption.title = setYAxisName$3(theme, iChartOption.yAxisName, iChartOption.chartPadding, iChartOption.direction);
    this.baseOption.tooltip = setTooltip$a(theme, iChartOption.tipHtml);
    this.baseOption.legend = setLegend$5(theme, iChartOption.legend);
    const legendData = getLegendData$2(iChartOption.data, xAxisKey);
    const xAxisData = getXAxisData$1(iChartOption.data, xAxisKey);
    const seriesData2 = getSeriesData(iChartOption.data, legendData);
    this.baseOption.legend.data = legendData;
    this.baseOption.xAxis.data = xAxisData;
    this.baseOption.series = setSeries$4(seriesData2, legendData, theme, iChartOption);
    this.baseOption.dataZoom = setDataZoom(theme, iChartOption.dataZoom);
    this.baseOption.grid.top = iChartOption.chartPadding[0];
    this.baseOption.grid.right = iChartOption.chartPadding[1];
    this.baseOption.grid.bottom = iChartOption.chartPadding[2];
    this.baseOption.grid.left = iChartOption.chartPadding[3];
    setWaterFall(this.baseOption, iChartOption);
    setRange(this.baseOption, iChartOption);
    setMarkLine$3(this.baseOption, iChartOption);
    setDirection$1(this.baseOption, iChartOption.direction);
    setLimitFormatter(this.baseOption, iChartOption);
    const echartsOption = iChartOption.echartsOption;
    if (echartsOption) {
      for (const opt in echartsOption) {
        this.baseOption[opt] = Object.assign(this.baseOption[opt], echartsOption[opt]);
      }
    }
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
BaseOption$7.tooltip = {
  show: true,
  trigger: "item",
  formatter: "{b}: {c} ({d}%)"
};
BaseOption$7.legend = {};
BaseOption$7.series = [];
function handleResObj(item, colors, index) {
  const resObj = __spreadProps(__spreadValues({}, item), {
    color: {
      rgba: codeToRGB(getColor(colors, index), 1),
      from: 1,
      to: 0.2
    }
  });
  return resObj;
}
function handleTempLegend(tempLegend, legendOffset, index) {
  if (tempLegend.orient === "horizontal") {
    const offset = legendOffset || 30;
    const bottom2 = parseFloat(tempLegend.bottom) - index * parseFloat(offset);
    if (tempLegend.bottom.toString().indexOf("%") !== -1) {
      tempLegend.bottom = `${bottom2}%`;
    } else {
      tempLegend.bottom = bottom2;
    }
  } else {
    const offset = legendOffset || 120;
    const left2 = parseFloat(tempLegend.left) + index * parseFloat(offset);
    if (tempLegend.left.toString().indexOf("%") !== -1) {
      tempLegend.left = `${left2}%`;
    } else {
      tempLegend.left = left2;
    }
  }
}
function handleTempSeriesObj(item) {
  const tempSeriesObj = __spreadProps(__spreadValues({}, item), {
    itemStyle: {
      color: item.color.rgba
    }
  });
  return tempSeriesObj;
}
function installInnerData(data2, innerData, innerIndex) {
  data2.children && data2.children.forEach((citem, cindex) => {
    if (!innerData[innerIndex]) {
      innerData[innerIndex] = [];
    }
    const colorFrom = data2.color.from - (data2.color.from - data2.color.to) / (data2.children.length + 1) * (cindex + 1);
    const colorTo = data2.color.from - (data2.color.from - data2.color.to) / (data2.children.length + 1) * (cindex + 2);
    citem.color = {
      rgba: changeRgbaOpacity(data2.color.rgba, colorFrom),
      from: colorFrom,
      to: colorTo
    };
    innerData[innerIndex].push(citem);
    if (citem.children) {
      installInnerData(citem, innerData, innerIndex + 1);
    }
  });
}
function handleMulti(type, baseOption, legend, data2) {
  if (type === "multi-circle") {
    const colors = baseOption.color;
    const outer = data2.map((item, index) => {
      const resObj = handleResObj(item, colors, index);
      return resObj;
    });
    const inner = [];
    const innerDiff = 6;
    const innerIndex = 0;
    outer.forEach((data3) => {
      installInnerData(data3, inner, innerIndex);
    });
    inner.forEach((innerData, innerIndex2) => {
      const tempSeries = cloneDeep(baseOption.series[0]);
      tempSeries.data = innerData.map((item) => {
        const tempSeriesObj = handleTempSeriesObj(item);
        return tempSeriesObj;
      });
      tempSeries.radius = tempSeries.radius.map((item) => {
        return `${parseFloat(item) + innerDiff * (innerIndex2 + 1)}%`;
      });
      baseOption.series.push(tempSeries);
    });
    baseOption.series.forEach((i) => {
      i.label = { show: false };
      i.labelLine = { show: false };
    });
    const dataArray = [outer].concat(inner);
    const originLegend = baseOption.legend;
    const legendOffset = legend.offset;
    baseOption.legend = [];
    dataArray.forEach((array, index) => {
      const tempLegend = cloneDeep(originLegend);
      const tempLegendData = array.map((item) => {
        return item.name;
      });
      tempLegend.data = tempLegendData;
      handleTempLegend(tempLegend, legendOffset, index);
      baseOption.legend.push(tempLegend);
    });
  }
}
const seriesInit$4 = {
  type: "pie",
  roundCap: true,
  radius: ["0%", "50%"],
  center: ["50%", "50%"],
  avoidLabelOverlap: false,
  itemStyle: {
    borderWidth: 3,
    borderColor: "#ffffff"
  },
  label: {},
  labelLine: {},
  data: []
};
function handleHasLabel(hasLabel, seriesUnit, theme) {
  if (hasLabel) {
    seriesUnit.label = { color: theme == "dark" ? "#eeeeee" : "#191919" };
  } else {
    seriesUnit.label = { show: false };
  }
}
function handleHasLabelLine(hasLabelLine, seriesUnit, label2, theme) {
  if (hasLabelLine) {
    seriesUnit.labelLine = {
      show: true,
      lineStyle: { color: theme == "dark" ? "#eeeeee" : "#191919" },
      smooth: 0.3,
      length: label2 !== void 0 ? label2.distance !== void 0 ? label2.distance : 25 : 25,
      length2: label2 !== void 0 ? label2.distance !== void 0 ? label2.distance : 25 : 25
    };
  } else {
    seriesUnit.labelLine = {
      show: false,
      length: label2 !== void 0 ? label2.distance !== void 0 ? label2.distance : 25 : 25,
      length2: label2 !== void 0 ? label2.distance !== void 0 ? label2.distance : 25 : 25
    };
  }
}
function hasLabelFormatterFun(labelFormatterType, seriesUnit, sum2) {
  switch (labelFormatterType) {
    case "percent":
      seriesUnit.label.formatter = (params) => {
        if (params.value == 0) {
          return "0\uFF080 %\uFF09";
        } else {
          return `${params.value}\uFF08${Math.round(params.value * 100 / sum2 * 100) / 100} %\uFF09`;
        }
      };
      break;
    case "value":
      seriesUnit.label.formatter = (params) => {
        return `${params.value}`;
      };
      break;
  }
}
function handleHasLabelFormatter(hasLabel, hasLabelFormatter, seriesUnit, labelFormatterType, sum2) {
  if (hasLabel && hasLabelFormatter) {
    seriesUnit.label.formatter = hasLabelFormatter;
  } else {
    hasLabelFormatterFun(labelFormatterType, seriesUnit, sum2);
  }
}
function setLabel(theme, seriesUnit, label2, data2) {
  const hasLabel = !(label2 && label2.show === false);
  const hasLabelLine = !(label2 && label2.line === false);
  const hasLabelFormatter = label2 && label2.labelHtml;
  const labelFormatterType = label2 && label2.type || "";
  let sum2 = data2.reduce((x, y) => ({ value: x.value + y.value }), { value: 0 });
  sum2 = sum2.value;
  handleHasLabel(hasLabel, seriesUnit, theme);
  handleHasLabelLine(hasLabelLine, seriesUnit, label2, theme);
  handleHasLabelFormatter(hasLabel, hasLabelFormatter, seriesUnit, labelFormatterType, sum2);
}
function setPieRadius(pieType, radius) {
  if (radius) {
    return radius;
  } else {
    let radius2 = [];
    switch (pieType) {
      case "pie":
        radius2 = ["0%", "50%"];
        break;
      case "circle":
        radius2 = ["44%", "50%"];
        break;
      case "multi-circle":
        radius2 = ["44%", "50%"];
        break;
      default:
        radius2 = ["0%", "50%"];
        break;
    }
    return radius2;
  }
}
function handleSeries$2(pieType, theme, iChartOption, chartPosition) {
  const { data: data2, label: label2, itemStyle } = iChartOption;
  chartPosition = chartPosition || {};
  if (itemStyle && itemStyle.borderColor) {
    seriesInit$4.itemStyle.borderColor = itemStyle.borderColor;
  } else {
    switch (theme) {
      case "dark":
        seriesInit$4.itemStyle.borderColor = darkColor;
        break;
      default:
        seriesInit$4.itemStyle.borderColor = lightColor;
        break;
    }
  }
  if (itemStyle && itemStyle.borderRadius) {
    seriesInit$4.itemStyle.borderRadius = itemStyle.borderRadius;
  }
  if (itemStyle && itemStyle.borderWidth) {
    seriesInit$4.itemStyle.borderWidth = itemStyle.borderWidth;
  }
  const series = [];
  const seriesUnit = cloneDeep(seriesInit$4);
  seriesUnit.data = data2;
  setLabel(theme, seriesUnit, label2, data2);
  seriesUnit.center = chartPosition.center || ["50%", "50%"];
  seriesUnit.radius = setPieRadius(pieType, chartPosition.radius);
  series.push(seriesUnit);
  return series;
}
function setTooltip$9(theme, formatter) {
  let PieTooltip = {};
  switch (theme) {
    case "dark":
      PieTooltip = cloneDeep(darkTooltip);
      break;
    default:
      PieTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    PieTooltip.formatter = formatter;
  }
  PieTooltip.trigger = "item";
  return PieTooltip;
}
const horizontalPageIcons = {
  horizontal: [
    `path://M8.925 15.96l12.351-12.351c0.521-0.521 0.521-1.365 0-1.886s-1.365-0.521-1.886 
    0l-13.199 13.199c-0.573 0.573-0.573 1.501 0 2.074l13.199 13.199c0.521 0.521 1.365 0.521 
    1.886 0s0.521-1.365 0-1.886l-12.351-12.351z`,
    `path://M 20.141 15.96 l -12.351 -12.351 c -0.521 -0.521 -0.521 -1.365 0 -1.886 s 1.365 
    -0.521 1.886 0 l 13.199 13.199 c 0.573 0.573 0.573 1.501 0 2.074 l -13.199 13.199 c -0.521 
     0.521 -1.365 0.521 -1.886 0 s -0.521 -1.365 0 -1.886 l 12.351 -12.351 Z`
  ]
};
const verticalPageIcons = {
  vertical: [
    `path://M8.925 15.96l12.351-12.351c0.521-0.521 0.521-1.365 0-1.886s-1.365-0.521-1.886 
     0l-13.199 13.199c-0.573 0.573-0.573 1.501 0 2.074l13.199 13.199c0.521 0.521 1.365 0.521 
     1.886 0s0.521-1.365 0-1.886l-12.351-12.351z`,
    `path://M 20.141 15.96 l -12.351 -12.351 c -0.521 -0.521 -0.521 -1.365 0 -1.886 s 1.365 
    -0.521 1.886 0 l 13.199 13.199 c 0.573 0.573 0.573 1.501 0 2.074 l -13.199 13.199 c 
    -0.521 0.521 -1.365 0.521 -1.886 0 s -0.521 -1.365 0 -1.886 l 12.351 -12.351 Z`
  ]
};
function handleLegend(legend, selfLegend) {
  const { show: show2, orient: orient2, type, pageButtonPosition, width } = selfLegend;
  if (!show2) {
    legend.show = false;
  }
  if (orient2) {
    legend.orient = orient2;
  }
  if (type) {
    legend.type = type;
  }
  if (pageButtonPosition) {
    legend.pageButtonPosition = pageButtonPosition;
  }
  if (width) {
    legend.width = width;
  }
  if (orient2 === "horizontal") {
    legend.pageIcons = horizontalPageIcons;
  } else if (orient2 === "vertical") {
    legend.pageIcons = verticalPageIcons;
  }
  legend.align = "left";
  if (selfLegend.formatter) {
    legend.formatter = function(name) {
      return `{a|${selfLegend.formatter(name)}}`;
    };
  }
  if (selfLegend.tipHtml) {
    legend.tooltip = {
      show: true,
      formatter: selfLegend.tipHtml
    };
  }
}
function setLegend$4(theme, selfLegend) {
  const { position, itemGap, icon, itemHeight, itemWidth } = selfLegend;
  let legend = {};
  switch (theme) {
    case "dark":
      legend = cloneDeep(darkLegend);
      legend.pageTextStyle = {
        color: lightColor
      };
      legend.pageIconColor = lightColor;
      legend.pageIconInactiveColor = lightAxisLabel;
      break;
    default:
      legend = cloneDeep(lightLegend);
      legend.pageTextStyle = {
        color: darkColor
      };
      legend.pageIconColor = darkColor;
      legend.pageIconInactiveColor = darkAxisLabel;
      break;
  }
  handleLegend(legend, selfLegend);
  legend.top = position.top || "auto";
  legend.left = position.left || "auto";
  legend.right = position.right || "auto";
  legend.bottom = position.bottom || "auto";
  delete legend.data;
  legend.itemGap = itemGap || 30;
  legend.icon = icon || "circle";
  legend.itemWidth = itemWidth || 25;
  legend.itemHeight = itemHeight || 14;
  return legend;
}
function setTitle$1(theme, PieText) {
  if (!PieText) {
    return {};
  }
  const PieMain = PieText.main;
  const PieSub = PieText.sub;
  const textPpsition = PieText.position;
  const PieTitle = {
    text: (PieMain == null ? void 0 : PieMain.text) || "",
    subtext: (PieSub == null ? void 0 : PieSub.text) || "",
    top: (textPpsition == null ? void 0 : textPpsition.top) || "40%",
    left: (textPpsition == null ? void 0 : textPpsition.left) || "center",
    right: (textPpsition == null ? void 0 : textPpsition.right) || "auto",
    bottom: (textPpsition == null ? void 0 : textPpsition.bottom) || "auto",
    itemGap: 8,
    textAlign: "center",
    textStyle: {
      color: theme == "dark" ? darkFontColor : lightFontColor,
      fontSize: (PieMain == null ? void 0 : PieMain.textSize) || 28,
      lineHeight: Number(PieMain == null ? void 0 : PieMain.textSize) * 1 || 28,
      fontWeight: "normal"
    },
    subtextStyle: {
      color: theme == "dark" ? "#949494" : lightFontColor,
      fontSize: (PieSub == null ? void 0 : PieSub.textSize) || 16,
      lineHeight: (PieSub == null ? void 0 : PieSub.textSize) * 1.2 || 24,
      fontWeight: "normal"
    }
  };
  return PieTitle;
}
class PieChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    const type = iChartOption.type || "circle";
    this.baseOption.color = iChartOption.color;
    this.baseOption.title = setTitle$1(theme, iChartOption.text);
    this.baseOption.tooltip = setTooltip$9(theme, iChartOption.tipHtml);
    this.baseOption.legend = setLegend$4(theme, iChartOption.legend);
    this.baseOption.series = handleSeries$2(type, theme, iChartOption, iChartOption.chartPosition);
    handleMulti(type, this.baseOption, iChartOption.legend, iChartOption.data);
    const echartsOption = iChartOption.echartsOption;
    if (echartsOption) {
      for (const opt in echartsOption) {
        this.baseOption[opt] = Object.assign(this.baseOption[opt], echartsOption[opt]);
      }
    }
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
BaseOption$7.tooltip = {
  show: true,
  trigger: "item",
  formatter: "{b}: {c} ({d}%)"
};
BaseOption$7.legend = {};
BaseOption$7.series = [];
BaseOption$7.radar = [];
const seriesInit$3 = {
  type: "radar",
  radarIndex: 0,
  symbolSize: 10,
  itemStyle: {
    borderWidth: 2
  },
  areaStyle: {
    opacity: 0.2
  },
  emphasis: {
    focus: "none",
    areaStyle: {
      opacity: 0.5
    }
  },
  data: []
};
function setSeries$3(theme, radarKeys, data2) {
  seriesInit$3.itemStyle.borderColor = theme == "dark" ? darkColor : lightColor;
  const series = [];
  const dataNames = Object.keys(data2);
  const seriesUnit = cloneDeep(seriesInit$3);
  dataNames.forEach((name) => {
    const radarData = {
      name,
      value: radarKeys.map((key) => {
        return data2[name][key];
      })
    };
    seriesUnit.data.push(radarData);
  });
  series.push(seriesUnit);
  return series;
}
function handleRedPointerRadar(chartPosition, radarKeys, dataNameIndex, radarMax) {
  const redPointerRadar = {
    center: chartPosition.center || ["50%", "50%"],
    radius: chartPosition.radius || "50%",
    name: {
      show: false
    },
    startAngle: 90 + 360 / radarKeys.length * dataNameIndex,
    splitNumber: 4,
    shape: "circle",
    splitArea: {
      show: false
    },
    axisLine: {
      show: true,
      lineStyle: {
        width: 1,
        color: "transparent"
      }
    },
    splitLine: {
      lineStyle: {
        width: 1,
        color: "transparent"
      }
    },
    indicator: [{ name: "", max: radarMax }]
  };
  return redPointerRadar;
}
function handleRedPointerSeries(index, theme, dataValue, seriesName) {
  const redPointerSeries = {
    type: "radar",
    symbolSize: 10,
    silent: true,
    z: 99,
    radarIndex: 2 + index,
    itemStyle: {
      color: marklineColor,
      borderColor: theme == "dark" ? darkColor : lightColor,
      borderWidth: 2,
      shadowBlur: 15,
      shadowColor: marklineColor
    },
    lineStyle: {
      width: 0,
      labelLine: {
        show: false
      }
    },
    data: [
      {
        value: dataValue,
        name: seriesName
      }
    ]
  };
  return redPointerSeries;
}
function getExceededMarkLineValue(data2, markLineValue) {
  const obj = [];
  const names = Object.keys(data2);
  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    const keys = Object.keys(data2[name]);
    for (let j = 0; j < keys.length; j++) {
      const key = keys[j];
      if (data2[name][key] >= markLineValue) {
        obj.push({
          seriesName: name,
          dataName: key,
          dataValue: data2[name][key]
        });
      }
    }
  }
  return obj;
}
function setMarkLineSeries(baseOption, iChartOption, radarKeys) {
  let markLineValue = iChartOption.markLine;
  if (markLineValue !== void 0) {
    markLineValue = parseFloat(markLineValue);
    const theme = iChartOption.theme;
    const data2 = iChartOption.data;
    const exceeded = getExceededMarkLineValue(data2, markLineValue);
    const chartPosition = iChartOption.chartPosition || {};
    const radarMax = iChartOption.radarMax;
    exceeded.forEach((item, index) => {
      const seriesName = item.seriesName;
      const dataName = item.dataName;
      const dataNameIndex = radarKeys.indexOf(dataName);
      const dataValue = item.dataValue;
      const redPointerRadar = handleRedPointerRadar(chartPosition, radarKeys, dataNameIndex, radarMax);
      const redPointerSeries = handleRedPointerSeries(index, theme, dataValue, seriesName);
      baseOption.radar.push(redPointerRadar);
      baseOption.series.push(redPointerSeries);
    });
  }
}
function getRadarKeys(data2) {
  const radarKeys = [];
  const seriesNames = Object.keys(data2);
  for (let i = 0; i < seriesNames.length; i++) {
    const seriesName = seriesNames[i];
    const seriesData2 = data2[seriesName];
    const dataNames = Object.keys(seriesData2);
    for (let j = 0; j < dataNames.length; j++) {
      const dataName = dataNames[j];
      if (radarKeys.indexOf(dataName) == -1) {
        radarKeys.push(dataName);
      }
    }
  }
  return radarKeys;
}
function handleFormatter(formatter, tooltip, radarKeys, markLine) {
  if (formatter) {
    tooltip.formatter = (params, ticket, callback) => {
      return formatter(params, radarKeys, ticket, callback);
    };
  } else {
    tooltip.formatter = (params) => {
      const data2 = params.data;
      const dataName = data2.name;
      let htmlString = `<div style="margin-bottom:4px;">
                                        ${dataName}
                                  </div>`;
      if (markLine) {
        data2.value.forEach((item, index) => {
          const color2 = item >= markLine ? marklineColor : params.color;
          htmlString += `<div style="margin-bottom:4px;">
                                        <span style="display:inline-block;width:8px;
                                        height:8px;margin-right:8px;border-radius:5px;
                                        background-color:${color2};"></span>
                                        <span style="display:inline-block;margin-right:8px;
                                        min-width:60px;font-size:12px">${radarKeys[index]}</span>
                                        <span style="font-size:14px">${item || "-"}</span>
                                  </div>`;
        });
      } else {
        data2.value.forEach((item, index) => {
          htmlString += `<div style="margin-bottom:4px;">
                                            <span style="display:inline-block;width:8px;
                                            height:8px;margin-right:8px;border-radius:5px;background-color:${params.color};"></span>
                                            <span style="display:inline-block;margin-right:8px;
                                            min-width:60px;font-size:12px">${radarKeys[index]}</span>
                                            <span style="font-size:14px">${item || "-"}</span>
                                      </div>`;
        });
      }
      return htmlString;
    };
  }
}
function setTooltip$8(theme, radarKeys, iChartOption) {
  let RadarTooltip = {};
  const formatter = iChartOption.tipHtml;
  const markLine = iChartOption.markLine;
  switch (theme) {
    case "dark":
      RadarTooltip = cloneDeep(darkTooltip);
      break;
    default:
      RadarTooltip = cloneDeep(lightTooltip);
      break;
  }
  handleFormatter(formatter, RadarTooltip, radarKeys, markLine);
  RadarTooltip.trigger = "item";
  return RadarTooltip;
}
function setLegend$3(theme, selfLegend) {
  const { show: show2, position, orient: orient2 } = selfLegend;
  let RadarLegend = {};
  switch (theme) {
    case "dark":
      RadarLegend = cloneDeep(darkLegend);
      break;
    default:
      RadarLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    RadarLegend.show = false;
  }
  if (orient2) {
    RadarLegend.orient = orient2;
  }
  RadarLegend.top = position.top || "auto";
  RadarLegend.left = position.left || "auto";
  RadarLegend.right = position.right || "auto";
  RadarLegend.bottom = position.bottom || "auto";
  delete RadarLegend.data;
  return RadarLegend;
}
const splitArea = {
  show: false
};
function handleAxisLine$1(theme) {
  const axisLine = {
    lineStyle: {
      color: theme == "dark" ? darkAxis : lightAxis,
      width: 1
    }
  };
  return axisLine;
}
function handleAxisLabel(radarMark) {
  const axisLabel = {
    show: radarMark === false ? false : true,
    margin: -20
  };
  return axisLabel;
}
function handleSplitLine$1(theme) {
  const splitLine = {
    lineStyle: {
      color: theme == "dark" ? darkAxis : lightAxis,
      width: 1
    }
  };
  return splitLine;
}
function handleRich(theme) {
  const rich = {
    a: {
      color: theme == "dark" ? darkAxisLabel : lightAxisLabel,
      align: "center",
      fontSize: 12,
      lineHeight: 12
    },
    b: {
      color: theme == "dark" ? darkAxisLabel : lightAxisLabel,
      fontSize: 12,
      align: "center",
      lineHeight: 20,
      padding: [0, 0, 4, 0]
    },
    c: {
      color: marklineColor,
      fontSize: 12,
      align: "center",
      lineHeight: 20,
      padding: [0, 0, 4, 0]
    }
  };
  return rich;
}
function handleRader(iChartOption, indicator, dataLength, data2) {
  const chartPosition = iChartOption.chartPosition || {};
  const axisLine = handleAxisLine$1(iChartOption.theme);
  const axisLabel = handleAxisLabel(iChartOption.radarMark);
  const splitLine = handleSplitLine$1(iChartOption.theme);
  const rich = handleRich(iChartOption.theme);
  const markLineValue = iChartOption.markLine;
  const radar = {
    center: chartPosition.center || ["50%", "50%"],
    radius: chartPosition.radius || "50%",
    nameGap: 15,
    splitNumber: 4,
    shape: "circle",
    triggerEvent: false,
    axisLine,
    axisLabel,
    splitArea,
    splitLine,
    indicator,
    axisName: {
      rich,
      formatter: (indicatorName) => {
        if (dataLength == 1) {
          const d = data2[Object.keys(data2)[0]];
          const v = d[indicatorName];
          if (markLineValue && v >= markLineValue) {
            return `{c|${v}}{c|%}
{a|${indicatorName}}`;
          } else {
            return `{b|${v}}{b|%}
{a|${indicatorName}}`;
          }
        } else if (dataLength > 1) {
          return `{a|${indicatorName}}`;
        }
      }
    }
  };
  return radar;
}
function setRadar(radarKeys, iChartOption) {
  const data2 = iChartOption.data;
  const dataLength = Object.keys(data2).length;
  const radarMax = iChartOption.radarMax;
  const indicator = radarKeys.map((name, index) => {
    if (index == 0) {
      return { name, max: radarMax };
    } else {
      return { name, max: radarMax, axisLabel: { show: false } };
    }
  });
  const radar = handleRader(iChartOption, indicator, dataLength, data2);
  return radar;
}
function setMarkLine$2(baseOption, iChartOption, radarKeys) {
  const chartPosition = iChartOption.chartPosition || {};
  const radius = chartPosition.radius || "50%";
  const radarMax = iChartOption.radarMax;
  let markLineValue = iChartOption.markLine;
  if (markLineValue !== void 0) {
    markLineValue = parseFloat(markLineValue);
    const marklineRadius = markLineValue / radarMax * parseFloat(radius) + (radius.toString().indexOf("%") !== -1 ? "%" : "");
    const markline = {
      center: chartPosition.center || ["50%", "50%"],
      radius: marklineRadius,
      nameGap: 0,
      splitNumber: 1,
      shape: "circle",
      axisLine: {
        show: false
      },
      axisLabel: {
        show: false
      },
      splitArea: {
        show: false
      },
      splitLine: {
        lineStyle: {
          width: 1,
          color: marklineColor,
          type: "dashed"
        }
      },
      indicator: new Array(radarKeys.length).fill({ name: "" })
    };
    baseOption.radar.push(markline);
  }
}
function getRadarMax(data2) {
  let max2;
  const names = Object.keys(data2);
  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    const keys = Object.keys(data2[name]);
    for (let j = 0; j < keys.length; j++) {
      const key = keys[j];
      if (max2 == void 0) {
        max2 = data2[name][key];
      }
      max2 = Math.max(max2, data2[name][key]);
    }
  }
  return max2;
}
class RadarChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    this.baseOption.color = iChartOption.color;
    if (iChartOption.markLine !== void 0) {
      iChartOption.markLine = parseFloat(iChartOption.markLine);
    }
    iChartOption.radarMax = iChartOption.radarMax || getRadarMax(iChartOption.data);
    const radarKeys = getRadarKeys(iChartOption.data);
    this.baseOption.radar.push(setRadar(radarKeys, iChartOption));
    this.baseOption.tooltip = setTooltip$8(theme, radarKeys, iChartOption);
    this.baseOption.legend = setLegend$3(theme, iChartOption.legend);
    this.baseOption.series = setSeries$3(theme, radarKeys, iChartOption.data);
    setMarkLine$2(this.baseOption, iChartOption, radarKeys);
    setMarkLineSeries(this.baseOption, iChartOption, radarKeys);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
BaseOption$7.series = [];
BaseOption$7.tooltip = {
  show: true,
  trigger: "item",
  formatter: "{b}: {c} ({d}%)"
};
BaseOption$7.legend = {};
const emptySeriesUnit = {
  type: "gauge",
  startAngle: 0,
  endAngle: 0,
  center: ["50%", "50%"],
  radius: "50%",
  splitNumber: 2,
  axisLine: { show: false },
  axisLabel: { show: false },
  splitLine: { show: false },
  itemStyle: { show: false },
  axisTick: { show: false },
  pointer: { show: false },
  detail: { show: false },
  title: { show: false },
  data: []
};
const seriesInit$2 = {
  type: "gauge",
  axisLine: {
    roundCap: true,
    lineStyle: {
      width: 10
    }
  },
  progress: {
    show: true,
    roundCap: true,
    width: 10
  },
  splitNumber: 4,
  splitLine: {
    distance: 0,
    length: 10,
    lineStyle: {
      width: 2
    }
  },
  axisLabel: {
    distance: 16,
    fontSize: 14,
    color: "red"
  },
  axisTick: {
    distance: 0,
    length: 10,
    lineStyle: {
      color: "transparent",
      width: 2
    }
  },
  pointer: {
    show: false,
    icon: "path://M511.999488 819.413462 72.8374 204.586538 951.1626 204.586538Z",
    length: "10%",
    width: 16,
    offsetCenter: [0, "-108%"]
  },
  title: {
    show: false
  },
  detail: {
    valueAnimation: true
  },
  data: []
};
function handleSplitLine(iChartOption, seriesUnit) {
  if (iChartOption.splitLine) {
    if (iChartOption.splitLine.show !== void 0) {
      seriesUnit.splitLine.show = iChartOption.splitLine.show;
    } else {
      seriesUnit.splitLine.show = true;
    }
  } else {
    seriesUnit.splitLine.show = true;
  }
  if (seriesUnit.splitLine.show) {
    seriesUnit.splitNumber = iChartOption.splitNumber || 4;
  } else {
    seriesUnit.splitNumber = -1;
  }
  if (iChartOption.itemStyle && iChartOption.itemStyle.splitLineColor) {
    seriesUnit.splitLine.lineStyle.color = iChartOption.itemStyle.splitLineColor;
  }
  if (iChartOption.itemStyle && iChartOption.itemStyle.splitLineDistance) {
    seriesUnit.splitLine.distance = iChartOption.itemStyle.splitLineDistance;
  }
  if (iChartOption.itemStyle && iChartOption.itemStyle.axisLabelDistance) {
    seriesUnit.axisLabel.distance = iChartOption.itemStyle.axisLabelDistance;
  }
}
function handleTheme(theme) {
  switch (theme) {
    case "dark":
      seriesInit$2.axisLine.lineStyle.color = [[1, darkSecondaryColor]];
      seriesInit$2.splitLine.lineStyle.color = darkAxis;
      seriesInit$2.axisLabel.color = darkAxisLabel;
      break;
    default:
      seriesInit$2.axisLine.lineStyle.color = [[1, lightSecondaryColor]];
      seriesInit$2.splitLine.lineStyle.color = lightAxis;
      seriesInit$2.axisLabel.color = lightAxisLabel;
      break;
  }
}
function handleDetail(seriesUnit, text, data2, theme) {
  seriesUnit.detail.formatter = text.formatter || function(value) {
    return `{value|${value}}
{name|${data2[0].name}}`;
  };
  seriesUnit.detail.offsetCenter = text.offset || [0, 0];
  seriesUnit.detail.rich = text.formatterStyle || {
    value: {
      fontSize: 60,
      fontWeight: "bolder",
      color: theme == "dark" ? darkFontColor : lightFontColor
    },
    name: {
      fontSize: 14,
      color: theme == "dark" ? darkFontColor : lightFontColor,
      padding: [24, 0, 0, 0]
    }
  };
}
function handleProgress(seriesUnit, iChartOption) {
  seriesUnit.progress.width = iChartOption.itemStyle ? iChartOption.itemStyle.width ? iChartOption.itemStyle.width : 10 : 10;
}
function handleAxisLine(seriesUnit, iChartOption) {
  seriesUnit.axisLine.lineStyle.width = iChartOption.itemStyle ? iChartOption.itemStyle.width ? iChartOption.itemStyle.width : 10 : 10;
}
function setSplitColor(series, splitColor) {
  series.axisLine.lineStyle.color = splitColor;
  series.axisLine.roundCap = false;
  series.progress.show = false;
  series.pointer.itemStyle = { color: "auto" };
}
function setGradientColor(series, gradientColor) {
  const linearColor = {
    type: "linear",
    x: 0,
    y: 0,
    x2: 1 / (series.data[0].value / series.max),
    y2: 0,
    colorStops: gradientColor.map((item, index) => {
      return {
        offset: index == 0 ? 0 : index / (gradientColor.length - 1),
        color: item
      };
    }),
    global: false
  };
  if (linearColor.colorStops.length == 1) {
    linearColor.colorStops.push({
      offset: 1,
      color: gradientColor[0]
    });
  }
  series.progress.itemStyle = { color: linearColor };
  series.pointer.itemStyle = { color: linearColor };
}
function setOuterHalo(seriesHalo, splitColor, theme) {
  const temp = cloneDeep(emptySeriesUnit);
  const outerGaugeHalo = __spreadProps(__spreadValues({}, temp), {
    startAngle: seriesHalo.startAngle,
    endAngle: seriesHalo.endAngle,
    center: seriesHalo.center,
    radius: `${parseFloat(seriesHalo.radius) + 5}%`,
    axisLine: {
      lineStyle: {
        width: 1,
        opacity: 0.3,
        color: splitColor
      }
    },
    splitNumber: splitColor.length,
    splitLine: {
      distance: 8,
      length: 10,
      lineStyle: {
        width: 2,
        color: ""
      }
    }
  });
  switch (theme) {
    case "dark":
      outerGaugeHalo.splitLine.lineStyle.color = "transparent";
      break;
    default:
      outerGaugeHalo.splitLine.lineStyle.color = "transparent";
      break;
  }
  return outerGaugeHalo;
}
function setProgressOuterHalo(series, gradientColor) {
  const temp = cloneDeep(emptySeriesUnit);
  const linearColor = {
    type: "linear",
    x: 0,
    y: 0,
    x2: 1,
    y2: 0,
    colorStops: gradientColor.map((item, index) => {
      return {
        offset: index == 0 ? 0 : index / (gradientColor.length - 1),
        color: item
      };
    }),
    global: false
  };
  const outerGauge = __spreadProps(__spreadValues({}, temp), {
    startAngle: series.startAngle,
    endAngle: series.endAngle,
    center: series.center,
    radius: `${parseFloat(series.radius) + 5}%`,
    axisLine: {
      lineStyle: {
        width: 1,
        opacity: 0.3,
        color: [[1, linearColor]]
      }
    }
  });
  return outerGauge;
}
function setMarkLine$1(series, markLine) {
  const temp = cloneDeep(emptySeriesUnit);
  const markGauge = __spreadProps(__spreadValues({}, temp), {
    min: series.min,
    max: series.max,
    startAngle: series.startAngle,
    endAngle: series.endAngle,
    center: series.center,
    radius: series.radius,
    animation: false,
    pointer: {
      icon: "path://M0 0 L30 0 L30 100 L0 100 Z",
      width: 3,
      length: 15,
      offsetCenter: [0, "-86%"],
      itemStyle: {
        color: marklineColor
      }
    },
    data: [
      {
        value: markLine
      }
    ]
  });
  return markGauge;
}
function handleOther(iChartOption, seriesUnit, series, theme, data2) {
  if (iChartOption.splitColor && iChartOption.splitColor.length > 0) {
    setSplitColor(seriesUnit, iChartOption.splitColor);
  } else if (iChartOption.gradientColor && iChartOption.gradientColor.length > 0) {
    setGradientColor(seriesUnit, iChartOption.gradientColor);
  }
  if (iChartOption.markLine && data2[0].value >= iChartOption.markLine) {
    seriesUnit.pointer.itemStyle = { color: marklineColor };
    seriesUnit.progress.itemStyle = { color: marklineColor };
  }
  series.push(seriesUnit);
  if (iChartOption.splitColor && iChartOption.splitColor.length > 0) {
    const outerGauge = setOuterHalo(seriesUnit, iChartOption.splitColor, theme);
    series.push(outerGauge);
  } else if (iChartOption.gradientColor && iChartOption.gradientColor.length > 1) {
    const outerGauge = setProgressOuterHalo(seriesUnit, iChartOption.gradientColor);
    series.push(outerGauge);
  }
  if (iChartOption.markLine) {
    const markGauge = setMarkLine$1(seriesUnit, iChartOption.markLine);
    series.push(markGauge);
  }
}
function handleSeries$1(iChartOption) {
  const theme = iChartOption.theme;
  const data2 = iChartOption.data;
  const text = iChartOption.text || {};
  const chartPosition = iChartOption.chartPosition || {};
  handleTheme(theme);
  const series = [];
  const seriesUnit = cloneDeep(seriesInit$2);
  seriesUnit.data = data2;
  handleSplitLine(iChartOption, seriesUnit);
  handleDetail(seriesUnit, text, data2, theme);
  handleProgress(seriesUnit, iChartOption);
  handleAxisLine(seriesUnit, iChartOption);
  seriesUnit.pointer.show = iChartOption.pointer || false;
  seriesUnit.center = chartPosition.center || ["50%", "50%"];
  seriesUnit.radius = chartPosition.radius || "70%";
  seriesUnit.min = iChartOption.min || 0;
  seriesUnit.max = iChartOption.max || 100;
  seriesUnit.startAngle = iChartOption.startAngle == void 0 ? 225 : iChartOption.startAngle;
  seriesUnit.endAngle = iChartOption.endAngle == void 0 ? -45 : iChartOption.endAngle;
  handleOther(iChartOption, seriesUnit, series, theme, data2);
  return series;
}
function setTooltip$7(theme, formatter) {
  let GaugeTooltip = {};
  switch (theme) {
    case "dark":
      GaugeTooltip = cloneDeep(darkTooltip);
      break;
    default:
      GaugeTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    GaugeTooltip.formatter = formatter;
  }
  GaugeTooltip.trigger = "item";
  return GaugeTooltip;
}
class GaugeChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    this.baseOption.color = iChartOption.color;
    this.baseOption.tooltip = setTooltip$7(theme, iChartOption.tipHtml);
    this.baseOption.series = handleSeries$1(iChartOption, this.baseOption.color);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
function getLegendData$1(data2) {
  return Object.keys(data2);
}
function getXAxisData(data2) {
  const xAxisData = [];
  data2.forEach((item) => {
    xAxisData.push(item[0]);
  });
  return xAxisData;
}
const seriesInit$1 = {
  data: [],
  type: "scatter",
  emphasis: {
    label: {
      show: true,
      color: "#ffffff",
      fontSize: 14,
      formatter(param) {
        return param.data[3];
      },
      position: "top"
    }
  },
  itemStyle: {}
};
function setSeries$2({ theme, legendData, data: data2, markLine, color: color2 }) {
  switch (theme) {
    case "dark":
      seriesInit$1.emphasis.label.color = darkAxisLabel;
      break;
    default:
      seriesInit$1.emphasis.label.color = lightAxisLabel;
      break;
  }
  const series = [];
  legendData.forEach((legend, index) => {
    const seriesUnit = cloneDeep(seriesInit$1);
    const itemColor = getColor(color2, index);
    const itemBorderColor = codeToRGB(itemColor, 0.2);
    if (markLine) {
      seriesUnit.markLine = cloneDeep(markLineDefault);
      if (markLine.y) {
        seriesUnit.markLine.data.push({ yAxis: markLine.y });
      }
      if (markLine.x) {
        seriesUnit.markLine.data.push({ xAxis: markLine.x });
      }
    }
    seriesUnit.name = legend;
    seriesUnit.data = data2[legend];
    seriesUnit.itemStyle = {
      color: itemBorderColor,
      borderColor: itemColor,
      borderWidth: 1
    };
    series.push(seriesUnit);
  });
  return series;
}
function setXAxis$2(theme) {
  let xAxis = {};
  switch (theme) {
    case "dark":
      xAxis = cloneDeep(darkXaxis);
      break;
    default:
      xAxis = cloneDeep(lightXaxis);
      break;
  }
  return xAxis;
}
function setYAxis$2(theme) {
  let yAxis = {};
  switch (theme) {
    case "dark":
      yAxis = cloneDeep(darkYaxis);
      break;
    default:
      yAxis = cloneDeep(lightYaxis);
      break;
  }
  return yAxis;
}
function setYAxisName$2(theme, name, chartPadding) {
  if (name) {
    const BubbleYAxisName = cloneDeep(yAxisNameDefault);
    BubbleYAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
    BubbleYAxisName.text = name;
    BubbleYAxisName.padding[0] = chartPadding[0] - 30;
    BubbleYAxisName.padding[3] = chartPadding[3];
    return BubbleYAxisName;
  }
  return {};
}
function tooltipFormatter(params) {
  const seriesName = params.seriesName;
  const color2 = params.color;
  const data2 = params.data;
  const [x, y, radius, name] = data2;
  let htmlString = `<div style="margin-bottom:4px;">
                                ${seriesName}
                         </div>`;
  htmlString += `<div style="margin-bottom:4px;">
                            <span style="display:inline-block;width:10px;height:10px;
                            margin-right:8px;border-radius:5px;border-style: solid;border-width:1px;
                            border-color:${changeRgbaOpacity(color2, 1)};background-color:${color2};"></span>
                            <span>${name}</span>
                       </div>`;
  htmlString += `
            <div>
                <span style="display:inline-block;margin-right:8px;min-width:60px;">x\u7EF4\u5EA6</span> 
                <span>${x}</span>
            </div>
        `;
  htmlString += `
            <div>
                <span style="display:inline-block;margin-right:8px;min-width:60px;">y\u7EF4\u5EA6</span> 
                <span>${y}</span>
            </div>
        `;
  htmlString += `
            <div>
                <span style="display:inline-block;margin-right:8px;min-width:60px;">\u534A\u5F84\u7EF4\u5EA6</span> 
                <span>${radius}</span>
            </div>
        `;
  return htmlString;
}
function setTooltip$6(theme, formatter) {
  let BubbleTooltip = {};
  switch (theme) {
    case "dark":
      BubbleTooltip = cloneDeep(darkTooltip);
      break;
    default:
      BubbleTooltip = cloneDeep(lightTooltip);
      break;
  }
  BubbleTooltip.trigger = "item";
  if (formatter) {
    BubbleTooltip.formatter = formatter;
  } else {
    BubbleTooltip.formatter = tooltipFormatter;
  }
  return BubbleTooltip;
}
function setLegend$2(theme, selfLegend) {
  const { show: show2, position, orient: orient2 } = selfLegend;
  let BubbleLegend = {};
  switch (theme) {
    case "dark":
      BubbleLegend = cloneDeep(darkLegend);
      break;
    default:
      BubbleLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    BubbleLegend.show = false;
  }
  if (orient2) {
    BubbleLegend.orient = orient2;
  }
  BubbleLegend.itemStyle = {
    borderWidth: 1
  };
  BubbleLegend.top = position.top || "auto";
  BubbleLegend.left = position.left || "auto";
  BubbleLegend.right = position.right || "auto";
  BubbleLegend.bottom = position.bottom || "auto";
  return BubbleLegend;
}
function handleTrendLine(option, iChartOption, plugins) {
  const ecStat = plugins.ecStat;
  if (iChartOption.trendLineConfig) {
    if (ecStat) {
      echarts.registerTransform(ecStat.transform.regression);
      const theme = iChartOption.theme;
      option.dataset.push({
        transform: {
          type: "ecStat:regression",
          config: iChartOption.trendLineConfig
        }
      });
      option.series.push({
        name: "trendline",
        type: "line",
        smooth: true,
        datasetIndex: 1,
        symbolSize: 0.1,
        symbol: "circle",
        label: {
          show: true,
          fontSize: 14,
          color: theme == "dark" ? darkAxisLabel : lightAxisLabel
        },
        labelLayout: {
          dx: -20
        },
        encode: {
          label: 2,
          tooltip: 1
        },
        silent: true
      });
    } else {
      throw new Error("\u60A8\u5FC5\u987B\u5B89\u88C5echarts-stat\u624D\u53EF\u4EE5\u4F7F\u7528\u8D8B\u52BF\u7EBF\u529F\u80FD");
    }
  }
}
function setVisualMap$1(baseOption, iChartOption, legendData) {
  const visualMap = [];
  const bubbleSize = iChartOption.bubbleSize || [10, 70];
  const radius = baseOption.dataset[0].source.map((item) => {
    return item[2];
  });
  const minValue = min(radius);
  const maxValue = max(radius);
  const seriesIndex = new Array(legendData.length).fill(0).map((item, index) => {
    return index;
  });
  visualMap.push({
    show: false,
    dimension: 2,
    min: minValue,
    max: maxValue,
    seriesIndex,
    inRange: {
      symbolSize: bubbleSize
    }
  });
  return visualMap;
}
function setDataset(baseOption, iChartOption) {
  let source = [];
  Object.keys(iChartOption.data).forEach((key) => {
    source = source.concat(iChartOption.data[key]);
  });
  return [
    {
      source
    }
  ];
}
class BubbleChart {
  constructor(iChartOption, plugins) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption(plugins);
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption(plugins) {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    this.baseOption.color = iChartOption.color;
    this.baseOption.xAxis = setXAxis$2(theme);
    this.baseOption.yAxis = setYAxis$2(theme);
    this.baseOption.title = setYAxisName$2(theme, iChartOption.yAxisName, iChartOption.chartPadding);
    this.baseOption.tooltip = setTooltip$6(theme, iChartOption.tipHtml);
    this.baseOption.legend = setLegend$2(theme, iChartOption.legend);
    const legendData = getLegendData$1(iChartOption.data);
    if (typeof iChartOption.data[legendData[0]][0][0] == "string") {
      this.baseOption.xAxis.type = "category";
      this.baseOption.xAxis.data = getXAxisData(iChartOption.data[legendData[0]]);
    } else {
      this.baseOption.xAxis.type = "value";
    }
    this.baseOption.legend.data = legendData;
    this.baseOption.series = setSeries$2({
      theme,
      legendData,
      data: iChartOption.data,
      markLine: iChartOption.markLine,
      color: this.baseOption.color
    });
    this.baseOption.dataset = setDataset(this.baseOption, iChartOption);
    this.baseOption.visualMap = setVisualMap$1(this.baseOption, iChartOption, legendData);
    this.baseOption.grid.top = iChartOption.chartPadding[0];
    this.baseOption.grid.right = iChartOption.chartPadding[1];
    this.baseOption.grid.bottom = iChartOption.chartPadding[2];
    this.baseOption.grid.left = iChartOption.chartPadding[3];
    handleTrendLine(this.baseOption, iChartOption, plugins);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
BaseOption$7.xAxis = {
  show: false
};
BaseOption$7.yAxis = {
  show: false
};
function setTooltip$5(theme, iChartOption) {
  let tooltip = {};
  const formatter = iChartOption.tipHtml;
  switch (theme) {
    case "dark":
      tooltip = cloneDeep(darkTooltip);
      break;
    default:
      tooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    tooltip.formatter = (params, ticket, callback) => {
      return formatter(params, ticket, callback);
    };
  }
  tooltip.trigger = "item";
  return tooltip;
}
const seriesInit = {
  type: "wordCloud",
  gridSize: 16,
  shape: "circle",
  sizeRange: [16, 64],
  rotationRange: [0, 0],
  rotationStep: 0,
  top: "center",
  left: "center",
  right: null,
  bottom: null,
  width: "75%",
  height: "80%",
  drawOutOfBound: false,
  layoutAnimation: true,
  textStyle: {
    color() {
      return `rgb(${[Math.round(getRandom * 256), Math.round(getRandom * 256), Math.round(getRandom * 256)].join(",")})`;
    }
  },
  emphasis: {
    textStyle: {
      textShadowBlur: 20,
      textShadowOffsetY: 2,
      textShadowOffsetX: 2,
      textShadowColor: "#191919"
    }
  },
  data: []
};
function handleSeries(params) {
  const {
    theme,
    data: data2,
    width,
    height,
    gridSize,
    sizeRange,
    rotationRange,
    rotationStep,
    shape,
    maskImage,
    textColor: textColor2,
    colors
  } = params;
  seriesInit.emphasis.textStyle.textShadowColor = theme == "dark" ? darkSecondaryColor : lightSecondaryColor;
  const series = [];
  const seriesUnit = cloneDeep(seriesInit);
  if (maskImage) {
    seriesUnit.maskImage = maskImage;
  }
  seriesUnit.width = width || "75%";
  seriesUnit.height = height || "80%";
  seriesUnit.gridSize = gridSize || 16;
  seriesUnit.sizeRange = sizeRange || [16, 64];
  seriesUnit.rotationRange = rotationRange || [0, 0];
  seriesUnit.rotationStep = rotationStep || 0;
  seriesUnit.shape = shape || "circle";
  if (textColor2) {
    seriesUnit.textStyle.color = textColor2;
  } else {
    seriesUnit.textStyle.color = (data3) => {
      const index = data3.dataIndex;
      return getColor(colors, index);
    };
  }
  seriesUnit.data = data2;
  series.push(seriesUnit);
  return series;
}
class BarChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$7);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    this.baseOption.color = iChartOption.color;
    this.baseOption.tooltip = setTooltip$5(theme, iChartOption);
    this.baseOption.series = handleSeries({
      theme,
      data: iChartOption.data,
      width: iChartOption.width,
      height: iChartOption.height,
      gridSize: iChartOption.gridSize,
      sizeRang: iChartOption.sizeRange,
      rotationRange: iChartOption.rotationRange,
      rotationStep: iChartOption.rotationStep,
      shape: iChartOption.shape,
      maskImage: iChartOption.maskImage,
      textColor: iChartOption.textColor,
      colors: this.baseOption.color
    });
    this.baseOption.grid.top = iChartOption.chartPadding[0];
    this.baseOption.grid.right = iChartOption.chartPadding[1];
    this.baseOption.grid.bottom = iChartOption.chartPadding[2];
    this.baseOption.grid.left = iChartOption.chartPadding[3];
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const data = [];
const textColor = "";
const right = 0;
const top = 0;
const bottom = 0;
const left = 0;
const nodeGap = 0;
const nodeWidth = 0;
const orient = "";
const BaseOption$6 = {
  tooltip: {
    trigger: "item",
    triggerOn: "mousemove"
  },
  animation: true,
  series: [
    {
      nodeAlign: "left",
      orient,
      right,
      top,
      bottom,
      left,
      nodeGap,
      nodeWidth,
      type: "sankey",
      data: data.nodes,
      links: data.links,
      emphasis: {
        focus: "adjacency"
      },
      layout: "none",
      focusNodeAdjaceny: true,
      layoutIterations: 32,
      levels: [
        {
          depth: 0,
          label: {
            position: "left"
          }
        }
      ],
      lineStyle: {
        color: "gradient",
        opacity: 0.6,
        curveness: 0.5
      },
      itemStyle: {
        borderWidth: 4,
        borderType: "solid",
        borderJoin: "round"
      },
      label: {
        color: textColor,
        fontSize: "12px",
        fontFamily: "HuaweiSans",
        distance: 10,
        position: "right",
        formatter: (params) => {
          if (params.name !== "empty" && params.name !== "virtical") {
            return `${params.name}
${params.data.valueBfb}`;
          } else {
            return "";
          }
        }
      }
    }
  ]
};
function isMove(draggable, baseOpt) {
  if (draggable === void 0) {
    draggable = true;
  }
  baseOpt.series[0].draggable = draggable;
}
function handleTooltip(params) {
  if (params.data.value !== 0 && params.data.valueBfb !== "0%") {
    let htmlString = "";
    if (params.name.includes(">")) {
      params.name = params.name.replace(">", "---");
    }
    const value = params.data.value || params.value;
    htmlString += `<span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">${params.name}</span><br/><span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">value  :  ${value}</span>`;
    return htmlString;
  }
}
function handleSankeyFormatter(formatter, SkTooltip) {
  if (formatter) {
    SkTooltip.formatter = formatter;
  } else {
    SkTooltip.formatter = (params) => {
      let html = "";
      html = handleTooltip(params);
      return html;
    };
  }
}
function setTooltip$4(theme, formatter) {
  let SkTooltip = {};
  switch (theme) {
    case "dark":
      SkTooltip = cloneDeep(darkTooltip);
      break;
    default:
      SkTooltip = cloneDeep(lightTooltip);
      break;
  }
  handleSankeyFormatter(formatter, SkTooltip);
  SkTooltip.trigger = "item";
  return SkTooltip;
}
function padSize(chartPadding, baseOpt) {
  baseOpt.series[0].top = chartPadding[0];
  baseOpt.series[0].right = chartPadding[1];
  baseOpt.series[0].bottom = chartPadding[2];
  baseOpt.series[0].left = chartPadding[3];
}
function sumBfb(links, nodes) {
  let sourceData = [];
  links.forEach((item) => {
    if (!sourceData.includes(item.source)) {
      sourceData.push(item.source);
    }
  });
  links.forEach((item) => {
    if (sourceData.includes(item.target)) {
      sourceData = sourceData.filter((items) => {
        return items !== item.target;
      });
    }
  });
  let valueSum = 0;
  nodes.forEach((itemn) => {
    sourceData.forEach((items) => {
      if (items === itemn.name) {
        valueSum += itemn.value;
      }
    });
  });
  nodes.forEach((itemn) => {
    if (!itemn.value) {
      itemn.value = 0;
    }
    itemn.valueBfb = itemn.value * 100 / valueSum;
    itemn.valueBfb = itemn.valueBfb.toFixed(0);
    itemn.valueBfb += "%";
  });
}
function setWidthSpace(widthSpace, baseOpt) {
  if (!widthSpace || widthSpace.length === 0) {
    widthSpace = [10, 30];
  }
  baseOpt.series[0].nodeWidth = widthSpace[0];
  baseOpt.series[0].nodeGap = widthSpace[1];
}
function setDirection(orient2, baseOpt) {
  if (orient2 === void 0) {
    orient2 = "horizontal";
  }
  if (orient2 === "vertical") {
    baseOpt.series[0].label.position = "bottom";
    baseOpt.series[0].levels[0].label.position = "top";
  }
  baseOpt.series[0].orient = orient2;
}
function setAlign(nodeAlign, baseOpt) {
  if (nodeAlign === void 0) {
    nodeAlign = "left";
  }
  baseOpt.series[0].nodeAlign = nodeAlign;
}
function setColor$1(color2, baseOpt, theme) {
  if (!color2 || color2.length === 0) {
    if (theme === "dark") {
      color2 = darkColorGroup;
    } else {
      color2 = lightColorGroup;
    }
  }
  const data2 = baseOpt.series[0].data;
  data2.forEach((item, index) => {
    item.itemStyle = {
      color: Array.isArray(color2) ? getColor(color2, index) : color2,
      borderColor: Array.isArray(color2) ? getColor(color2, index) : color2
    };
  });
}
function setTextColor(theme, baseOpt) {
  if (theme === "dark") {
    baseOpt.series[0].label.color = darkFontColor;
  } else {
    baseOpt.series[0].label.color = lightFontColor;
  }
}
function handleEmptyData(nodes, links) {
  let flag = false;
  const virtualData = [];
  nodes.forEach((itemn) => {
    itemn.value = itemn.value - 0;
    if (itemn.value === 0) {
      itemn.value = 5;
      virtualData.push(itemn.name);
      flag = true;
    }
  });
  if (flag) {
    nodes.unshift({ name: "virtical", value: 0, itemStyle: { color: "transparent" } });
    nodes.push({ name: "empty", value: 0, itemStyle: { color: "transparent" } });
    virtualData.unshift("virtical");
  }
  virtualData.forEach((item) => {
    links.push({
      source: item,
      target: "empty",
      value: -9999999999
    });
  });
}
class SankeyChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$6);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    const { nodes, links } = iChartOption.data;
    this.baseOption.series[0].data = nodes;
    this.baseOption.series[0].links = links;
    isMove(iChartOption.draggable, this.baseOption);
    setColor$1(iChartOption.color, this.baseOption, theme);
    setTextColor(theme, this.baseOption);
    this.baseOption.tooltip = setTooltip$4(theme, iChartOption.tipHtml);
    padSize(iChartOption.chartPadding, this.baseOption);
    sumBfb(links, nodes);
    setWidthSpace(iChartOption.widthSpace, this.baseOption);
    handleEmptyData(nodes, links);
    setDirection(iChartOption.orient, this.baseOption);
    setAlign(iChartOption.nodeAlign, this.baseOption);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const BaseOption$5 = {
  xAxis: {
    show: false,
    type: "value"
  },
  yAxis: [
    {
      type: "category",
      inverse: true,
      axisLabel: {
        show: false
      },
      splitLine: {
        show: false
      },
      axisTick: {
        show: false
      },
      axisLine: {
        show: false
      },
      data: []
    },
    {
      type: "category",
      inverse: true,
      axisTick: {
        show: false
      },
      axisLine: {
        show: false
      },
      show: true,
      axisLabel: {
        show: false
      },
      data: []
    }
  ],
  series: [
    {
      name: "data",
      type: "bar",
      zlevel: 2,
      barWidth: 8,
      itemStyle: {
        normal: {
          borderRadius: 4,
          color: () => {
            return "";
          }
        }
      },
      label: {
        normal: {
          show: true,
          color: "",
          position: [0, -20],
          textStyle: { fontSize: 14 },
          formatter: () => {
            return "";
          }
        }
      },
      data: []
    },
    {
      name: "mask",
      type: "bar",
      zlevel: 1,
      silent: true,
      itemStyle: {
        normal: {
          color: ""
        }
      },
      barWidth: 10,
      data: []
    },
    {
      name: "background",
      type: "bar",
      barWidth: 8,
      barGap: "-100%",
      silent: true,
      itemStyle: {
        color: "",
        borderRadius: 4
      },
      emphasis: {
        disabled: true
      },
      label: {
        normal: {
          show: true,
          color: "",
          offset: [0, -24],
          position: "insideTopRight",
          textStyle: { fontSize: 14 },
          formatter: () => {
            return "";
          }
        }
      },
      data: []
    }
  ]
};
class ProcessBarChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    this.baseOption = cloneDeep(BaseOption$5);
    this.updateOption(iChartOption);
  }
  handleTheme(theme) {
    switch (theme) {
      case "dark":
        this.baseOption.series[1].itemStyle.normal.color = darkBackgroundColor;
        this.baseOption.series[2].itemStyle.color = darkSecondaryColor;
        this.baseOption.series[2].label.normal.color = darkAxisLabel;
        this.baseOption.series[0].label.normal.color = darkAxisLabel;
        this.baseOption.tooltip = cloneDeep(darkTooltip);
        break;
      default:
        this.baseOption.series[1].itemStyle.normal.color = lightBackgroundColor;
        this.baseOption.series[2].itemStyle.color = "#eeeeee";
        this.baseOption.series[2].label.normal.color = lightAxisLabel;
        this.baseOption.series[0].label.normal.color = lightAxisLabel;
        this.baseOption.tooltip = cloneDeep(lightTooltip);
        break;
    }
  }
  handleFormatter() {
    this.baseOption.tooltip.formatter = (params) => {
      const name = params[0].name;
      const value = params[0].value;
      const color2 = params[0].color;
      const htmlString = `
                        <div>
                            <span style="display:inline-block;width:10px;height:10px;
                            border-radius:5px;background-color:${color2};">
                            </span>
                            <span style="margin-left:5px;">
                                <span style="display:inline-block;margin-right:8px;min-width:80px;">${name}</span> 
                                <span style="font-weight:bold">${value}%</span>
                            </span>
                        </div>
                    `;
      return htmlString;
    };
  }
  updateOption(iChartOption) {
    const theme = iChartOption.theme;
    const color2 = iChartOption.color;
    const data2 = iChartOption.data;
    const barData = [];
    const barName = [];
    const maskData = [];
    data2.forEach((item) => {
      barData.push(item.value);
      barName.push(item.name);
      maskData.push(item.value == 100 ? 0 : item.value + 1);
    });
    this.baseOption.series[0].data = barData;
    this.baseOption.series[1].data = maskData;
    this.baseOption.series[2].data = new Array(barData.length).fill(100);
    this.handleTheme(theme);
    this.baseOption.series[0].itemStyle.normal.color = function(params) {
      return getColor(color2, params.dataIndex);
    };
    this.baseOption.series[0].label.normal.formatter = function(params) {
      return params.name;
    };
    this.baseOption.series[2].label.normal.formatter = function(params) {
      return `${barData[params.dataIndex]}%`;
    };
    this.baseOption.yAxis[0].data = barName;
    this.baseOption.yAxis[1].data = barData;
    this.baseOption.tooltip.axisPointer = { type: "none" };
    this.handleFormatter();
  }
  getOption() {
    return this.baseOption;
  }
  setOption(option) {
    this.baseOption = option;
  }
}
const seriesData = [];
const colorData = [];
const findColor = [];
const renderItem = "";
const BaseOption$4 = {
  dataset: [
    {
      source: seriesData
    }
  ],
  color: colorData,
  legend: {
    data: findColor,
    icon: "circle",
    left: "center",
    bottom: 0,
    textStyle: {
      color: "#fff"
    }
  },
  hoverLayerThreshold: Infinity,
  series: [
    {
      type: "custom",
      colorBy: "data",
      renderItem,
      name: "selfcustom",
      coordinateSystem: "none",
      encode: {
        tooltip: "value",
        itemName: "id"
      }
    }
  ]
};
function setLegend$1(theme, selfLegend) {
  const { show: show2, position, orient: orient2 } = selfLegend;
  let SpBubbleLegend = {};
  switch (theme) {
    case "dark":
      SpBubbleLegend = cloneDeep(darkLegend);
      break;
    default:
      SpBubbleLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    SpBubbleLegend.show = false;
  }
  if (orient2) {
    SpBubbleLegend.orient = orient2;
  }
  SpBubbleLegend.top = position.top || "auto";
  SpBubbleLegend.left = position.left || "auto";
  SpBubbleLegend.right = position.right || "auto";
  SpBubbleLegend.bottom = position.bottom || "auto";
  delete SpBubbleLegend.data;
  return SpBubbleLegend;
}
function setTooltip$3(theme, formatter) {
  let SpBubbleTooltip = {};
  switch (theme) {
    case "dark":
      SpBubbleTooltip = cloneDeep(darkTooltip);
      break;
    default:
      SpBubbleTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    SpBubbleTooltip.formatter = formatter;
  } else {
    SpBubbleTooltip.formatter = (params) => {
      let htmlString = "";
      const bgColor = params.data.colorSec || params.data.color;
      htmlString += `<span style="display:inline-block;margin-right:5px;border-radius:50%;width:10px;height:10px;background-color
        :${bgColor};"></span><span style="display:inline-block;margin-left:5px">${params.data.type}</span><br/><span style="display:inline-block;">${params.data.label}</span><span style="display:inline-block;margin-left:10px;">${params.data.value}</span><br/>`;
      return htmlString;
    };
  }
  SpBubbleTooltip.trigger = "item";
  return SpBubbleTooltip;
}
function getLegendData(data2) {
  const legendData = [];
  if (data2.length > 0) {
    data2.forEach((item) => {
      if (!legendData.includes(item.type) && item.type !== "") {
        legendData.push(item.type);
      }
    });
  }
  return legendData;
}
function colorfun(color2, type) {
  color2 = color2.map((item) => {
    if (type === "non-nested" || type === "non-nested-aggregate") {
      item = `${item},8`;
    } else {
      item = `${item},0.2`;
    }
    item = codeToRGB(item.substring(0, item.lastIndexOf(",")), item.substring(item.lastIndexOf(",") + 1) - 0);
    return item;
  });
  return color2;
}
function depthFirstfun(params) {
  const { depthFirst, findColor: findColor2, muchColor, colorData: colorData2, color: color2, type, seriesData: seriesData2, colorLegend } = params;
  depthFirst.forEach((_item) => {
    if (!findColor2.includes(_item.type)) {
      findColor2.push(_item.type);
      muchColor.push(_item);
      muchColor.forEach((item, index) => {
        item.color = getColor(color2, index);
      });
      _item.colorSec = _item.color.replace("0.", "1");
      _item.colorBg = _item.color.replace("0.2", "0.1");
      colorData2.push(_item.color);
      colorData2.push(_item.colorSec);
      colorData2.push(_item.colorBg);
      if (type === "non-nested") {
        seriesData2.forEach((item) => {
          if (item.showLabel === false || !item.showLabel) {
            item.colorSec = "rgba(31,85,181,.2)";
          }
        });
      }
      colorLegend.push(_item.colorSec);
    } else {
      muchColor.forEach((item) => {
        if (_item.type === item.type) {
          _item.color = item.color;
        }
      });
    }
  });
}
function handleColor(params) {
  const { depthFirst, findColor: findColor2, muchColor, colorData: colorData2, seriesData: seriesData2, type, colorLegend, depthMore, theme } = params;
  let color2 = params.color;
  color2 = colorfun(color2, type);
  depthFirstfun({ depthFirst, findColor: findColor2, muchColor, colorData: colorData2, color: color2, type, seriesData: seriesData2, colorLegend });
  seriesData2.forEach((item) => {
    item.labelS = item.label;
    if (theme === "dark") {
      item.textColor = lightColor;
    } else {
      item.textColor = darkColor;
    }
    if (item.showLabel === false || !item.showLabel) {
      item.labelS = "";
    }
  });
  if (type === "non-nested") {
    seriesData2.forEach((item) => {
      if (item.showLabel === false || !item.showLabel) {
        item.color = "rgba(31,85,181,.2)";
      }
    });
  }
  if (depthMore.length) {
    depthMore.forEach((item) => {
      depthFirst.forEach((_item) => {
        if (_item.id === item.id.substring(0, item.id.lastIndexOf("."))) {
          item.color = _item.color;
          item.colorSec = _item.colorSec;
          item.colorBg = _item.colorBg;
        }
      });
    });
  }
}
function overallLayout(params, api, distance, displayRoot, d3) {
  const context = params.context;
  d3.pack().size([api.getWidth() - 2, api.getHeight() - 2]).padding(distance)(displayRoot);
  context.nodes = {};
  displayRoot.descendants().forEach(function(node) {
    context.nodes[node.id] = node;
  });
}
function setChartPosition(params) {
  const { iChartOption, height, width } = params;
  let { radius, widthDis, heightDis } = params;
  if (!iChartOption.chartPosition) {
    iChartOption.chartPosition = { center: ["50%", "50%"], radius: "80%" };
  } else {
    if (!iChartOption.chartPosition.center) {
      iChartOption.chartPosition.center = ["50%", "50%"];
    } else {
      if (!iChartOption.chartPosition.radius) {
        iChartOption.chartPosition.radius = "80%";
      }
    }
  }
  radius = iChartOption.chartPosition.radius || "80%";
  if (typeof radius !== "number") {
    if (radius.indexOf("%") !== -1) {
      radius = (radius.substring(0, radius.indexOf("%")) - 0) / 100;
    } else {
      radius = parseFloat(radius) / Math.min(height, width);
    }
  } else {
    radius = radius / Math.min(height, width);
  }
  let leftValue = iChartOption.chartPosition.center[0] || "50%";
  if (typeof leftValue !== "number") {
    if (leftValue.indexOf("%") !== -1) {
      leftValue = (leftValue.substring(0, leftValue.indexOf("%")) - 0) / 100;
      widthDis = width * (leftValue - radius / 2);
    } else {
      widthDis = parseFloat(leftValue);
    }
  } else {
    widthDis = leftValue;
  }
  let topValue = iChartOption.chartPosition.center[1] || "50%";
  if (typeof topValue !== "number") {
    if (topValue.indexOf("%") !== -1) {
      topValue = (topValue.substring(0, topValue.indexOf("%")) - 0) / 100;
      heightDis = height * (topValue - radius / 2);
    } else {
      heightDis = parseFloat(topValue);
    }
  } else {
    heightDis = topValue;
  }
  return { radius, widthDis, heightDis };
}
function returnValue(params) {
  const { node, radius, widthDis, heightDis, nodeName, type, z2 } = params;
  const value = {
    type: "circle",
    shape: {
      cx: node.x * radius + widthDis,
      cy: node.y * radius + heightDis,
      r: node.r * radius > 0 ? node.r * radius : -node.r * radius
    },
    transition: ["shape"],
    z2,
    textContent: {
      type: "text",
      style: {
        text: nodeName,
        fontFamily: "Arial",
        width: node.r,
        height: node.r,
        borderRadius: node.r,
        overflow: "visible",
        fontSize: node.r / 3 > 12 ? node.r / 3 : "12px",
        fill: node.data.textColor
      },
      emphasis: {
        style: {
          overflow: null,
          fontSize: Math.max(node.r / 3, 12)
        }
      }
    },
    textConfig: { position: "inside" },
    style: {
      stroke: node.depth >= 1 && type === "nested" ? node.data.colorSec : null,
      fill: node.depth === 1 ? node.data.color : node.data.colorBg
    },
    keyframeAnimation: {
      duration: 3e3,
      loop: true,
      delay: getRandom() * 2e3,
      keyframes: [
        { y: -3, percent: 0.5, easing: "cubicOut" },
        { y: 0, percent: 1, easing: "bounceOut" },
        { x: -3, percent: 0.5, easing: "cubicOut" },
        { x: 0, percent: 1, easing: "bounceOut" }
      ]
    }
  };
  return value;
}
function handleRootData(params) {
  const { d3, seriesData: seriesData2, baseOpt, distance, length, type, chartInstance, iChartOption } = params;
  function stratify() {
    return d3.stratify().parentId(function(d) {
      return d.id.substring(0, d.id.lastIndexOf("."));
    })(seriesData2).sum(function(d) {
      return d.value || 0;
    }).sort(function(a, b) {
      return b.value - a.value;
    });
  }
  const displayRoot = stratify();
  function renderItem2(params2, api) {
    const context = params2.context;
    if (!context.layout) {
      context.layout = true;
      overallLayout(params2, api, distance, displayRoot, d3);
    }
    const nodePath = api.value("id");
    const node = context.nodes[nodePath];
    if (!node) {
      return;
    }
    const isLeaf = !node.children || !node.children.length;
    const nodeName = isLeaf ? node.data.labelS : "";
    const z2 = api.value("depth") * 2;
    const width = chartInstance.getWidth();
    const height = chartInstance.getHeight();
    let widthDis = "";
    let heightDis = "";
    let radius = "";
    radius = setChartPosition({ iChartOption, height, width, widthDis, heightDis, radius }).radius;
    widthDis = setChartPosition({ iChartOption, height, width, widthDis, heightDis, radius }).widthDis;
    heightDis = setChartPosition({ iChartOption, height, width, widthDis, heightDis, radius }).heightDis;
    return returnValue({ node, radius, widthDis, heightDis, nodeName, type, z2 });
  }
  baseOpt.series[length].renderItem = renderItem2;
}
function handleVirtualLengend(findColor2) {
  const virtualLegend = findColor2.map((item) => {
    return {
      name: item,
      type: "pie",
      data: [],
      radius: ["0%", "0%"],
      colorBy: "data"
    };
  });
  return virtualLegend;
}
function handleSeriesData(iChartOption, type, seriesData2) {
  const rootData = [
    {
      depth: 0,
      id: "option",
      value: 1255,
      type: "",
      label: 0
    }
  ];
  if (iChartOption.data.length) {
    if (type === "non-nested" || type === "non-nested-aggregate") {
      let nurId = 0;
      iChartOption.data.forEach((item) => {
        nurId++;
        item.depth = 1;
        item.id = `option.${nurId}`;
      });
      seriesData2 = rootData.concat(iChartOption.data);
    } else if (type === "nested") {
      let _nurId = 0;
      let __nurId = 0;
      iChartOption.data.forEach((item) => {
        _nurId++;
        item.depth = 1;
        item.id = `option.${_nurId}`;
        item.children.forEach((items) => {
          items.type = item.type;
          __nurId++;
          items.depth = 2;
          items.id = `${item.id}.${__nurId}`;
        });
      });
      const typeArr = [];
      seriesData2 = rootData.concat(iChartOption.data);
      seriesData2.forEach((item) => {
        if (!typeArr.includes(item.type)) {
          typeArr.push(item.type);
        }
      });
    } else {
      throw new Error("\u805A\u5408\u6C14\u6CE1\u56FE\u5FC5\u987B\u5B9A\u4E49type,\u503C\u4E3Anested\u6216non-nested\u6216non-nested-aggregate");
    }
  } else {
    throw new Error("\u805A\u5408\u6C14\u6CE1\u56FE\u5FC5\u987B\u5B9A\u4E49data\u6570\u636E");
  }
  return seriesData2;
}
function changeSeriesData(seriesData2) {
  const depthFirst = seriesData2.filter((item) => {
    return item.depth === 1;
  });
  const findColor2 = [];
  const muchColor = [];
  const colorData2 = [];
  const colorLegend = [];
  const depthMore = [];
  seriesData2.forEach((item) => {
    if (item.children) {
      Object.keys(item.children).forEach((items) => {
        depthMore.push(item.children[items]);
      });
    }
  });
  seriesData2.forEach((item) => {
    depthMore.forEach((itemd) => {
      if (itemd.type === item.type) {
        seriesData2.push(itemd);
      }
    });
  });
  return { depthFirst, depthMore, findColor: findColor2, muchColor, colorData: colorData2, colorLegend };
}
function color(theme, items, type) {
  if (theme === "dark") {
    items.color = darkSecondaryColor;
    items.colorSec = darkSecondaryColor;
    items.colorBg = darkSecondaryColor;
    items.textColor = darkSecondaryFontColor;
    if (items.depth >= 1 && type === "nested") {
      items.colorSec = darkBackgroundColor;
    }
  } else {
    items.color = lightSecondaryColor;
    items.colorSec = lightSecondaryColor;
    items.colorBg = lightSecondaryColor;
    items.textColor = lightSecondaryFontColor;
    if (items.depth >= 1 && type === "nested") {
      items.colorSec = lightBackgroundColor;
    }
  }
}
function show(params, items, itemc, theme, type) {
  if (!params.selected[itemc]) {
    if (items.type === itemc) {
      color(theme, items, type);
    }
  }
}
function legendDisappear(paramsd) {
  const { seriesData: seriesData2, params, theme, type, baseOpt, chartInstance } = paramsd;
  seriesData2.forEach((items) => {
    if (items.type === params.name) {
      color(theme, items, type);
    }
  });
  baseOpt.dataset[0].source = seriesData2;
  chartInstance.setOption(baseOpt);
}
function legendShow(paramss) {
  const { seriesData: seriesData2, type, theme, params, baseOpt, chartInstance } = paramss;
  seriesData2.forEach((items) => {
    if (items.type !== params.name) {
      Object.keys(params.selected).forEach((itemc) => {
        show(params, items, itemc, theme, type);
      });
    }
  });
  baseOpt.dataset[0].source = seriesData2;
  chartInstance.setOption(baseOpt);
}
function legendSelectChanged(iChartOption) {
  const distance = iChartOption.distance;
  const type = iChartOption.type;
  const theme = iChartOption.theme;
  let beforeData = [];
  beforeData = handleSeriesData(iChartOption, type, beforeData);
  const depthMore = [];
  beforeData.forEach((item) => {
    if (item.children) {
      Object.keys(item.children).forEach((items) => {
        depthMore.push(item.children[items]);
      });
    }
  });
  beforeData.forEach((item) => {
    depthMore.forEach((itemd) => {
      if (itemd.type === item.type) {
        beforeData.push(itemd);
      }
    });
  });
  return { distance, type, theme, beforeData };
}
function ConfigureLoadData(baseOptt, d3, iChartOption, seriesData2, chartInstance) {
  if (d3) {
    const theme = iChartOption.theme;
    baseOptt.tooltip = setTooltip$3(theme, iChartOption.tipHtml);
    const color2 = iChartOption.color;
    if (!color2.length) {
      throw Error("\u989C\u8272\u7EC4\u989C\u8272\u672A\u5B9A\u4E49");
    }
    const type = iChartOption.type;
    seriesData2 = handleSeriesData(iChartOption, type, seriesData2);
    let distance = iChartOption.distance;
    if (!distance) {
      if (type === "non-nested") {
        distance = 50;
      } else {
        distance = 5;
      }
    }
    baseOptt.legend = setLegend$1(theme, iChartOption.legend);
    const legendData = getLegendData(seriesData2);
    baseOptt.legend.data = legendData;
    baseOptt.dataset[0].source = seriesData2;
    const { depthFirst, depthMore, findColor: findColor2, muchColor, colorData: colorData2, colorLegend } = changeSeriesData(seriesData2);
    handleColor({
      depthFirst,
      findColor: findColor2,
      muchColor,
      colorData: colorData2,
      color: color2,
      seriesData: seriesData2,
      type,
      colorLegend,
      depthMore,
      theme
    });
    baseOptt.color = colorLegend;
    baseOptt.legend.data = findColor2;
    baseOptt.series.unshift(...handleVirtualLengend(findColor2));
    const length = findColor2.length;
    handleRootData({ d3, seriesData: seriesData2, baseOpt: baseOptt, distance, length, type, chartInstance, iChartOption });
    return { baseOptt, seriesData: seriesData2 };
  } else {
    throw new Error("\u60A8\u5FC5\u987B\u5B89\u88C5d3\u624D\u53EF\u4EE5\u4F7F\u7528\u805A\u5408\u6C14\u6CE1\u56FE");
  }
}
class AssembleBubbleChart {
  constructor(iChartOption, plugins, chartInstance) {
    __publicField(this, "baseOption");
    this.baseOption = cloneDeep(BaseOption$4);
    this.updateOption(iChartOption, plugins, chartInstance, this.baseOption);
  }
  updateOption(iChartOption, plugins, chartInstance, baseOpt) {
    let seriesData2 = [];
    const { type, theme } = legendSelectChanged(iChartOption);
    const color2 = iChartOption.color;
    chartInstance.on("legendselectchanged", function(params) {
      if (!params.selected[params.name]) {
        legendDisappear({ seriesData: seriesData2, params, theme, type, baseOpt, chartInstance });
      } else {
        const { depthFirst, depthMore, findColor: findColor2, muchColor, colorData: colorData2, colorLegend } = changeSeriesData(seriesData2);
        seriesData2 = Array.from(new Set(seriesData2));
        handleColor({
          depthFirst,
          findColor: findColor2,
          muchColor,
          colorData: colorData2,
          color: color2,
          seriesData: seriesData2,
          type,
          colorLegend,
          depthMore,
          theme
        });
        legendShow({ seriesData: seriesData2, type, theme, params, baseOpt, chartInstance });
      }
    });
    const d3 = plugins.d3;
    const { baseOptt } = ConfigureLoadData(this.baseOption, d3, iChartOption, seriesData2, chartInstance);
    this.baseOption = baseOptt;
    seriesData2 = ConfigureLoadData(this.baseOption, d3, iChartOption, seriesData2, chartInstance).seriesData;
  }
  getOption() {
    return this.baseOption;
  }
  setOption(option) {
    this.baseOption = option;
  }
}
const BaseOption$3 = {
  grid: {
    top: 30,
    bottom: 20,
    left: 24,
    right: 0
  },
  series: [
    {
      type: "line",
      symbol: "circle",
      itemStyle: {},
      label: {
        show: true,
        position: "top"
      },
      lineStyle: {
        shadowBlur: 0,
        shadowOffsetY: 0
      },
      markLine: {
        symbol: ["none"],
        label: {},
        lineStyle: {},
        data: [
          {
            yAxis: ""
          }
        ]
      }
    }
  ]
};
function setMark(mark, baseOpt, theme) {
  mark = mark ? mark : {};
  baseOpt.series[0].symbolSize = mark.symbolSize;
  if (!mark.textStyle) {
    if (theme === "dark") {
      mark.textStyle = {
        color: lightColor,
        fontSize: 12,
        lineHeight: 16
      };
    } else {
      mark.textStyle = {
        color: darkColor,
        fontSize: 12,
        lineHeight: 16
      };
    }
  } else {
    if (!mark.textStyle.color) {
      if (theme === "dark") {
        mark.textStyle.color = lightColor;
      } else {
        mark.textStyle.color = darkColor;
      }
    }
  }
  baseOpt.series[0].label.textStyle = mark.textStyle;
  baseOpt.series[0].label.formatter = mark.formatter;
  if (!mark.formatter) {
    baseOpt.series[0].label.formatter = () => {
      return "";
    };
  }
  baseOpt.series[0].itemStyle = mark.itemStyle;
  if (!mark.itemStyle) {
    baseOpt.series[0].itemStyle = {
      color: () => {
        return "transparent";
      }
    };
  }
}
function setToolTip(theme, show2, formatter) {
  if (show2 === false) {
    return;
  }
  let SpMarkerTooltip = {};
  switch (theme) {
    case "dark":
      SpMarkerTooltip = cloneDeep(darkTooltip);
      break;
    default:
      SpMarkerTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    SpMarkerTooltip.formatter = formatter;
  } else {
    SpMarkerTooltip.formatter = (params) => {
      let htmlString = "";
      params.forEach((item) => {
        htmlString += `<span style="display:inline-block;margin-right:10px;border-radius:50%;height:10px;">${item.name}</span><span style="display:inline-block;margin-left:10px;border-radius:50%;height:10px;">${item.data}</span>`;
      });
      return htmlString;
    };
  }
  SpMarkerTooltip.trigger = "axis";
  return SpMarkerTooltip;
}
function setMarkLine(markLine, baseOpt) {
  baseOpt.series[0].markLine.data[0].yAxis = markLine.top || "";
  baseOpt.series[0].markLine.silent = markLine.silent || false;
  baseOpt.series[0].markLine.label.formatter = markLine.topLable || "";
  if (markLine.topColor) {
    baseOpt.series[0].markLine.lineStyle.color = markLine.topColor;
  } else {
    baseOpt.series[0].markLine.lineStyle.color = "red";
  }
  if (markLine.labelColor) {
    baseOpt.series[0].markLine.label.color = markLine.labelColor;
  } else {
    baseOpt.series[0].markLine.label.color = "red";
  }
  baseOpt.series[0].markLine.label.position = markLine.labelPosition || "insideEndTop";
  baseOpt.series[0].markLine.label.fontSize = markLine.fontSize || 12;
  baseOpt.series[0].markLine.label.distance = markLine.distance || [0, 0];
}
function setXAxis$1(theme, xAxis, baseOpt, time) {
  switch (theme) {
    case "dark":
      xAxis = cloneDeep(darkXaxis);
      break;
    case "light":
      xAxis = cloneDeep(lightXaxis);
      break;
  }
  baseOpt.xAxis = xAxis;
  baseOpt.xAxis.data = time;
}
function setYAxis$1(theme, yAxis, baseOpt) {
  yAxis = yAxis ? yAxis : {};
  const interval = yAxis.interval;
  const max2 = yAxis.max;
  switch (theme) {
    case "dark":
      yAxis = cloneDeep(darkYaxis);
      break;
    case "light":
      yAxis = cloneDeep(lightYaxis);
      break;
  }
  baseOpt.yAxis = yAxis;
  baseOpt.yAxis.interval = interval;
  baseOpt.yAxis.max = max2;
  baseOpt.yAxis.nameTextStyle = {
    color: theme === "dark" ? darkAxisLabel : lightAxisLabel
  };
}
function setXData(params) {
  const { data: data2, xAxis, time, value, baseOpt, xAxisName } = params;
  const legendData = [];
  if (data2.length > 0) {
    const temp = data2[0];
    for (const key in temp) {
      if (key !== xAxisName) {
        legendData.push(key);
      }
    }
  }
  data2.forEach((item) => {
    time.push(item[xAxis]);
    value.push(item[legendData[0]]);
  });
  baseOpt.series[0].data = value;
  return time;
}
function setYAxisName$1(theme, name, chartPadding) {
  if (name) {
    const MarkYAxisName = cloneDeep(yAxisNameDefault);
    MarkYAxisName.text = name;
    MarkYAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
    MarkYAxisName.padding[0] = chartPadding[0] - 30;
    MarkYAxisName.padding[3] = chartPadding[3];
    return MarkYAxisName;
  }
  return {};
}
class MarkerLineChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    this.baseOption = cloneDeep(BaseOption$3);
    this.updateOption(iChartOption);
  }
  updateOption(iChartOption) {
    const theme = iChartOption.theme;
    const data2 = iChartOption.data;
    const xAxis = iChartOption.xAxis;
    let time = [];
    const value = [];
    const xAxisName = xAxis;
    time = setXData({ data: data2, xAxis, time, value, baseOpt: this.baseOption, xAxisName });
    const smooth = iChartOption.smooth || false;
    this.baseOption.series[0].smooth = smooth;
    const color2 = iChartOption.color;
    this.baseOption.color = color2;
    let tooltip = iChartOption.tooltip;
    if (tooltip) {
      this.baseOption.tooltip = setToolTip(theme, tooltip.show, tooltip.tipHtml);
    } else {
      tooltip = {
        show: true
      };
      this.baseOption.tooltip = setToolTip(theme, tooltip.show, tooltip.tipHtml);
    }
    setXAxis$1(theme, xAxis, this.baseOption, time);
    const yAxis = iChartOption.yAxis;
    setYAxis$1(theme, yAxis, this.baseOption);
    this.baseOption.title = setYAxisName$1(theme, iChartOption.yAxisName, iChartOption.chartPadding);
    const mark = iChartOption.mark;
    setMark(mark, this.baseOption, theme);
    const markPoint = iChartOption.markPoint;
    this.baseOption.series[0].markPoint = markPoint;
    const markLine = iChartOption.markLine;
    if (markLine) {
      setMarkLine(markLine, this.baseOption);
    } else {
      return "";
    }
  }
  getOption() {
    return this.baseOption;
  }
  setOption(option) {
    this.baseOption = option;
  }
}
class SpecialChart {
  constructor(iChartOption, plugins, newChart) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption(iChartOption, plugins, newChart);
  }
  updateOption(iChartOption, plugins, newChart) {
    if (!iChartOption.name) {
      throw new Error("SpecialChart must have a name");
    }
    let chartClass;
    switch (iChartOption.name) {
      case "ProcessBarChart":
        chartClass = ProcessBarChart;
        break;
      case "AssembleBubbleChart":
        chartClass = AssembleBubbleChart;
        break;
      case "MarkerLineChart":
        chartClass = MarkerLineChart;
        break;
    }
    const chart = new chartClass(iChartOption, plugins, newChart);
    this.baseOption = chart.getOption();
    this.baseOption.grid = {
      top: "0",
      left: "0",
      right: "0",
      bottom: "0",
      containLabel: true
    };
    this.baseOption.grid.top = iChartOption.chartPadding[0];
    this.baseOption.grid.right = iChartOption.chartPadding[1];
    this.baseOption.grid.bottom = iChartOption.chartPadding[2];
    this.baseOption.grid.left = iChartOption.chartPadding[3];
  }
  getOption() {
    return this.baseOption;
  }
  setOption(option) {
    this.baseOption = option;
  }
}
const BaseOption$2 = {
  color: [],
  grid: {
    top: "0",
    left: "0",
    right: "0",
    bottom: "0",
    containLabel: true
  },
  xAxis: {},
  yAxis: {},
  visualMap: {
    show: false,
    dimension: 2,
    type: "",
    min: "",
    max: "",
    inRange: {
      colorAlpha: [0, 1]
    }
  },
  series: [
    {
      type: "",
      data: []
    }
  ]
};
function setXAxis(theme, type, data2, iChartOption) {
  let xAxis = {};
  switch (theme) {
    case "dark":
      xAxis = cloneDeep(darkXaxis);
      break;
    default:
      xAxis = cloneDeep(lightXaxis);
      break;
  }
  switch (type) {
    case "RectangularHeatMapChart":
      xAxis.type = "value";
      xAxis.axisLine.show = false;
      break;
    case "CalendarHeatMapChart":
      xAxis.data = data2[0];
      xAxis.axisTick.show = false;
      xAxis.axisLabel.padding = [0, 0, 0, 10 * data2[0][0].length / 2];
      break;
    default:
      xAxis.type = "value";
      xAxis.axisLine.show = false;
      xAxis.axisTick.show = false;
      xAxis.axisLabel.show = false;
      xAxis.min = 0;
      xAxis.max = data2[1];
      break;
  }
  if (iChartOption.xAxisInterval !== void 0) {
    xAxis.axisLabel.interval = iChartOption.xAxisInterval;
  }
  return xAxis;
}
function handleYAxisOption(yAxisOption, yAxis) {
  if (yAxisOption && yAxisOption.unit) {
    yAxis.axisLabel.formatter = `{value} ${yAxisOption.unit}`;
    delete yAxisOption.unit;
  }
  if (yAxisOption && yAxisOption.formatter) {
    yAxis.axisLabel.formatter = yAxisOption.formatter;
  }
  if (yAxisOption && yAxisOption.interval) {
    yAxis.axisLabel.interval = yAxisOption.interval;
  }
  if (yAxisOption && yAxisOption.position && yAxisOption.name) {
    yAxisOption.nameTextStyle = Object.assign(yAxis.nameTextStyle, yAxisOption.nameTextStyle);
  }
  if (yAxisOption) {
    Object.assign(yAxis, yAxisOption);
  }
}
function setYAxis(theme, type, data2, yAxisOption) {
  let yAxis = {};
  switch (theme) {
    case "dark":
      yAxis = cloneDeep(darkYaxis);
      break;
    default:
      yAxis = cloneDeep(lightYaxis);
      break;
  }
  switch (type) {
    case "RectangularHeatMapChart":
      break;
    case "CalendarHeatMapChart":
      yAxis.type = "category";
      yAxis.data = data2[1];
      yAxis.splitLine.show = false;
      yAxis.axisLabel.margin = 20;
      yAxis.axisLine = {
        show: true,
        lineStyle: {
          width: 2,
          color: theme === "dark" ? darkAxis : lightAxis
        }
      };
      break;
    default:
      yAxis.axisLine.show = false;
      yAxis.splitLine.show = false;
      yAxis.axisLabel.show = false;
      yAxis.min = 0;
      yAxis.max = data2[2];
      break;
  }
  handleYAxisOption(yAxisOption, yAxis);
  return yAxis;
}
function setYAxisName(theme, name, baseOption) {
  if (name) {
    const yAxisName = cloneDeep(yAxisNameDefault);
    yAxisName.textStyle.color = theme == "dark" ? darkAxisLabel : lightAxisLabel;
    yAxisName.text = name;
    yAxisName.padding[0] = baseOption.grid.top - 30;
    yAxisName.padding[3] = baseOption.grid.left;
    return yAxisName;
  }
  return {};
}
function RectangularFormatter(params) {
  const color2 = params.color;
  const data2 = params.data;
  const [x, y, z, name] = data2;
  let htmlString = `<div style="margin-bottom:4px;">
                                \u77E9\u5F62\u70ED\u529B\u56FE
                            </div>`;
  htmlString += `<div style="margin-bottom:4px;">
                            <span style="display:inline-block;width:10px;height:10px;
                            margin-right:8px;border-style: solid;border-width:1px;
                            border-color:${changeRgbaOpacity(color2, 1)};background-color:${color2};"></span>
                            <span>${name}</span>
                        </div>`;
  htmlString += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;min-width:60px;">x\u7EF4\u5EA6</span> 
                                <span>${x}</span>
                            </div>`;
  htmlString += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;min-width:60px;">y\u7EF4\u5EA6</span> 
                                <span>${y}</span>
                            </div>`;
  htmlString += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;
                                min-width:60px;">\u900F\u660E\u5EA6\u7EF4\u5EA6</span> 
                                <span>${z}</span>
                            </div>`;
  return htmlString;
}
function CalendarFormatter(params) {
  const color2 = params.color;
  const data2 = params.data;
  const name = params.name;
  const [, , z] = data2;
  let htmlDom = `<div style="margin-bottom:4px;">
                                \u65E5\u5386\u70ED\u529B\u56FE
                            </div>`;
  htmlDom += `<div style="margin-bottom:4px;">
                            <span style="display:inline-block;width:10px;
                            height:10px;margin-right:8px;border-style: solid;
                            border-width:1px;border-color:${changeRgbaOpacity(color2, 1)};background-color:${color2};"></span>
                            <span>${name}</span>
                        </div>`;
  htmlDom += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;
                                min-width:60px;">Value</span> 
                                <span>${z}</span>
                            </div>`;
  return htmlDom;
}
function HexagonFormatter(params) {
  const color2 = params.color;
  const data2 = params.data;
  const [x, y, z, name] = data2;
  let html = `<div style="margin-bottom:4px;">
                            \u8702\u7A9D\u70ED\u529B\u56FE
                            </div>`;
  html += `<div style="margin-bottom:4px;">
                            <span style="display:inline-block;width:10px;
                            height:10px;margin-right:8px;border-style: solid;
                            border-width:1px;border-color:${changeRgbaOpacity(color2, 1)};background-color:${color2};"></span>
                            <span>${name}</span>
                        </div>`;
  html += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;min-width:60px;">x\u7EF4\u5EA6</span> 
                                <span>${x}</span>
                            </div>`;
  html += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;min-width:60px;">y\u7EF4\u5EA6</span> 
                                <span>${y}</span>
                            </div>`;
  html += `
                            <div>
                                <span style="display:inline-block;margin-right:8px;min-width:60px;">\u989C\u8272\u7EF4\u5EA6</span> 
                                <span>${z}</span>
                            </div>`;
  return html;
}
function setTooltip$2(theme, formatter, type) {
  let HeatTooltip = {};
  switch (theme) {
    case "dark":
      HeatTooltip = cloneDeep(darkTooltip);
      break;
    default:
      HeatTooltip = cloneDeep(lightTooltip);
      break;
  }
  HeatTooltip.trigger = "item";
  if (formatter) {
    HeatTooltip.formatter = formatter;
  } else {
    switch (type) {
      case "RectangularHeatMapChart":
        HeatTooltip.formatter = RectangularFormatter;
        break;
      case "CalendarHeatMapChart":
        HeatTooltip.formatter = CalendarFormatter;
        break;
      default:
        HeatTooltip.formatter = HexagonFormatter;
        break;
    }
  }
  return HeatTooltip;
}
function setColor(type, color2) {
  let symbolColor;
  if (!color2) {
    switch (type) {
      case "RectangularHeatMapChart":
        symbolColor = "#F43146";
        break;
      case "CalendarHeatMapChart":
        symbolColor = "#1F55B5";
        break;
      default:
        symbolColor = ["#FFFFFF", "#448DFF", "#4350EA", "#33307C ", "#242648", "#973152", "#F8364D"];
        break;
    }
  } else {
    symbolColor = color2;
  }
  return symbolColor;
}
function setTheme$1(iChartOption) {
  iChartOption.theme = iChartOption.theme || "light";
  return iChartOption.theme;
}
function setChartPadding$1(chartPadding, baseOption, type, handle) {
  const grid = baseOption.grid;
  let defaultPadding;
  switch (type) {
    case "CalendarHeatMapChart":
      defaultPadding = handle ? [50, 120, 20, 20] : [50, 30, 20, 20];
      break;
    default:
      defaultPadding = [50, 30, 20, 20];
      break;
  }
  if (!chartPadding) {
    grid.top = defaultPadding[0];
    grid.right = defaultPadding[1];
    grid.bottom = defaultPadding[2];
    grid.left = defaultPadding[3];
  } else if (chartPadding.length === 1) {
    grid.top = chartPadding[0];
    grid.right = defaultPadding[1];
    grid.bottom = chartPadding[0];
    grid.left = defaultPadding[3];
  } else if (chartPadding.length === 2) {
    grid.top = chartPadding[0];
    grid.right = chartPadding[1];
    grid.bottom = chartPadding[0];
    grid.left = chartPadding[1];
  } else if (chartPadding.length === 3) {
    grid.top = chartPadding[0];
    grid.right = chartPadding[1];
    grid.bottom = chartPadding[2];
    grid.left = chartPadding[1];
  } else {
    grid.top = chartPadding[0];
    grid.right = chartPadding[1];
    grid.bottom = chartPadding[2];
    grid.left = chartPadding[3];
  }
  return grid;
}
function getDataKeys(data2) {
  return Object.keys(data2);
}
function handleRectData(data2) {
  return data2;
}
function handleCategoryName(data2) {
  const defaultArr = [];
  data2.forEach((item) => {
    if (defaultArr.indexOf(item) === -1) {
      defaultArr.push(item);
    }
  });
  return defaultArr;
}
function handlecalendarSeriesData(xAxisData, yAxisData, data2, keyName) {
  return data2.map((item) => {
    return [xAxisData.indexOf(item[keyName[0]]), yAxisData.indexOf(item[keyName[1]]), item[keyName[2]]];
  });
}
function handleCalendarData(data2) {
  const calendarData = [];
  const keyName = getDataKeys(data2[0]);
  const xCategoryName = data2.map((item) => {
    return item[keyName[0]];
  });
  const yCategoryName = data2.map((item) => {
    return item[keyName[1]];
  });
  const xAxisData = handleCategoryName(xCategoryName);
  const yAxisData = handleCategoryName(yCategoryName);
  const calendarSeriesData = handlecalendarSeriesData(xAxisData, yAxisData, data2, keyName);
  calendarData.push(xAxisData);
  calendarData.push(yAxisData);
  calendarData.push(calendarSeriesData);
  return calendarData;
}
function computeCoordinates(arr, number, halfWidth, r) {
  return arr.map((item, index) => {
    const groupNumber = number * 2 - 1;
    const remainder = index % groupNumber;
    const group = index / groupNumber;
    const lineNumber = Math.floor(group);
    if (remainder < number - 1) {
      return [(remainder + 1) * 2 * halfWidth, (1 + 3 * lineNumber) * r, item, r];
    } else {
      return [((remainder - number + 1) * 2 + 1) * halfWidth, (1 + 1.5 * (2 * lineNumber + 1)) * r, item, r];
    }
  });
}
function handleHexagonData(data2, iChartOption) {
  const hexagonData = [];
  const number = iChartOption.quantity ? iChartOption.quantity : 40;
  const xValue = iChartOption.value ? iChartOption.value[0] : 100;
  const yValue = iChartOption.value ? iChartOption.value[1] : 60;
  const initialData = data2;
  const x = xValue / (2 * number);
  const r = x / Math.sqrt(0.75);
  const coordinatesArr = computeCoordinates(initialData, number, x, r);
  hexagonData.push(coordinatesArr);
  hexagonData.push(xValue);
  hexagonData.push(yValue);
  hexagonData.push(r);
  return hexagonData;
}
function getData(type, iChartOption) {
  let chartData;
  switch (type) {
    case "RectangularHeatMapChart":
      chartData = handleRectData(iChartOption.data);
      break;
    case "CalendarHeatMapChart":
      chartData = handleCalendarData(iChartOption.data);
      break;
    default:
      chartData = handleHexagonData(iChartOption.data, iChartOption);
      break;
  }
  return chartData;
}
function renderItemHexagonDark(params, api) {
  const center = api.coord([api.value(0), api.value(1)]);
  const points = [];
  const viewRadius = api.size([api.value(3), api.value(3)]);
  let angle = Math.PI / 6;
  for (let i = 0; i < 6; i++, angle += Math.PI / 3) {
    points.push([center[0] + viewRadius[0] * Math.cos(angle), center[1] + viewRadius[1] * Math.sin(angle)]);
  }
  return {
    type: "group",
    children: [
      {
        type: "polygon",
        shape: {
          points
        },
        style: {
          stroke: "#191919",
          fill: api.visual("color"),
          lineWidth: 1
        }
      }
    ]
  };
}
function renderItemHexagonLight(params, api) {
  const center = api.coord([api.value(0), api.value(1)]);
  const points = [];
  const viewRadius = api.size([api.value(3), api.value(3)]);
  let angle = Math.PI / 6;
  for (let i = 0; i < 6; i++, angle += Math.PI / 3) {
    points.push([center[0] + viewRadius[0] * Math.cos(angle), center[1] + viewRadius[1] * Math.sin(angle)]);
  }
  return {
    type: "group",
    children: [
      {
        type: "polygon",
        shape: {
          points
        },
        style: {
          stroke: "#fff",
          fill: api.visual("color"),
          lineWidth: 1
        }
      }
    ]
  };
}
function handleTypeSeries$1(type) {
  let seriesInit2 = {};
  switch (type) {
    case "RectangularHeatMapChart":
      seriesInit2 = {
        type: "scatter",
        symbol: "rect",
        symbolSize: "",
        cursor: "pointer",
        data: []
      };
      break;
    case "CalendarHeatMapChart":
      seriesInit2 = {
        name: "",
        type: "heatmap",
        cursor: "pointer",
        label: {
          show: void 0,
          color: ""
        },
        data: [],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: "rgba(0, 0, 0, 0.5)"
          }
        },
        itemStyle: {
          borderColor: ""
        },
        progressive: 1e3,
        animation: false
      };
      break;
    default:
      seriesInit2 = {
        type: "custom",
        name: "",
        renderItem: void 0,
        data: []
      };
      break;
  }
  return seriesInit2;
}
function setSeries$1(type, iChartOption, data2, theme) {
  const series = [];
  const seriesItem = handleTypeSeries$1(type);
  switch (type) {
    case "RectangularHeatMapChart":
      seriesItem.symbolSize = iChartOption.rectangleSize ? iChartOption.rectangleSize : 8;
      seriesItem.data = data2;
      break;
    case "CalendarHeatMapChart":
      seriesItem.data = data2[2];
      seriesItem.itemStyle.borderColor = iChartOption.borderColor ? iChartOption.borderColor : iChartOption.color;
      seriesItem.label.show = iChartOption.showLabel ? true : false;
      seriesItem.label.color = theme === "dark" ? darkFontColor : lightFontColor;
      if (iChartOption.changeProperty === "color") {
        seriesItem.itemStyle.borderWidth = 0;
      }
      break;
    default:
      seriesItem.data = data2[0];
      seriesItem.renderItem = theme === "dark" ? renderItemHexagonDark : renderItemHexagonLight;
      break;
  }
  series.push(seriesItem);
  return series;
}
function handleTypeVisualMap(type) {
  let visualMapUnit = {};
  switch (type) {
    case "RectangularHeatMapChart":
      visualMapUnit = {
        show: false,
        dimension: 2,
        min: "",
        max: "",
        inRange: {
          colorAlpha: [0, 1]
        }
      };
      break;
    case "CalendarHeatMapChart":
      visualMapUnit = {
        show: true,
        dimension: 2,
        min: "",
        max: "",
        inRange: {},
        inverse: true,
        itemWidth: 16,
        itemHeight: 400,
        text: [],
        textStyle: {
          color: "",
          fontSize: 14
        }
      };
      break;
    default:
      visualMapUnit = {
        show: false,
        type: "continuous",
        dimension: 2,
        min: "",
        max: "",
        inRange: {
          color: []
        }
      };
      break;
  }
  return visualMapUnit;
}
function handleCalendar(iChartOption, visualMapItem, maxValue, minValue, theme) {
  if (iChartOption.handle) {
    visualMapItem.inverse = iChartOption.handle.inverse ? true : false;
    visualMapItem.text = iChartOption.handle.text ? iChartOption.handle.text : [maxValue, minValue];
    visualMapItem.orient = iChartOption.handle.orient ? iChartOption.handle.orient : "vertical";
    visualMapItem.calculable = iChartOption.handle.calculable ? true : false;
    visualMapItem.textStyle.color = theme === "dark" ? darkFontColor : lightFontColor;
    visualMapItem.itemWidth = iChartOption.handle.width ? iChartOption.handle.width : 20;
    visualMapItem.itemHeight = iChartOption.handle.height ? iChartOption.handle.height : 400;
    if (iChartOption.handle.position) {
      Object.assign(visualMapItem, iChartOption.handle.position);
    } else {
      const defaultPosition = {
        right: "4%",
        bottom: "6%"
      };
      Object.assign(visualMapItem, defaultPosition);
    }
  }
  if (!iChartOption.changeProperty) {
    visualMapItem.inRange = { opacity: [0, 1] };
  } else if (iChartOption.changeProperty === "opcity") {
    visualMapItem.inRange = { opacity: [0, 1] };
  } else {
    visualMapItem.inRange = { color: iChartOption.color };
  }
}
function setVisualMap(type, data2, iChartOption, theme) {
  const visualMap = [];
  const visualMapItem = handleTypeVisualMap(type);
  let IntervalArr;
  let minValue;
  let maxValue;
  switch (type) {
    case "RectangularHeatMapChart":
      IntervalArr = data2.map((item) => {
        return item[2];
      });
      minValue = min(IntervalArr);
      maxValue = max(IntervalArr);
      visualMapItem.min = minValue;
      visualMapItem.max = maxValue;
      break;
    case "CalendarHeatMapChart":
      IntervalArr = data2[2].map((item) => {
        return item[2];
      });
      minValue = min(IntervalArr);
      maxValue = max(IntervalArr);
      visualMapItem.min = minValue;
      visualMapItem.max = maxValue;
      visualMapItem.show = iChartOption.handle ? true : false;
      handleCalendar(iChartOption, visualMapItem, maxValue, minValue, theme);
      break;
    default:
      IntervalArr = data2[0].map((item) => {
        return item[2];
      });
      minValue = min(IntervalArr);
      maxValue = max(IntervalArr);
      visualMapItem.min = minValue;
      visualMapItem.max = maxValue;
      visualMapItem.inRange.color = iChartOption.color;
      break;
  }
  visualMap.push(visualMapItem);
  return visualMap;
}
class HeatMapChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption");
    this.baseOption = cloneDeep(BaseOption$2);
    this.iChartOption = iChartOption;
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const type = iChartOption.type;
    if (!type) {
      throw new Error("HeatMapChart must have a name");
    }
    if (isFunction(iChartOption.data)) {
      iChartOption.data = iChartOption.data();
    }
    const theme = setTheme$1(iChartOption);
    this.baseOption.color = setColor(type, iChartOption.color);
    const data2 = getData(type, iChartOption);
    this.baseOption.xAxis = setXAxis(theme, type, data2, iChartOption);
    this.baseOption.yAxis = setYAxis(theme, type, data2, iChartOption.yAxis);
    this.baseOption.grid = setChartPadding$1(iChartOption.chartPadding, this.baseOption, type, iChartOption.handle);
    this.baseOption.title = setYAxisName(theme, iChartOption.yAxisName, this.baseOption);
    this.baseOption.tooltip = setTooltip$2(theme, iChartOption.tipHtml, type);
    this.baseOption.series = setSeries$1(type, iChartOption, data2, theme);
    this.baseOption.visualMap = setVisualMap(type, data2, iChartOption, theme);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const sum = 0;
const BaseOption$1 = {
  tooltip: {},
  angleAxis: {
    clockwise: true,
    min: 0,
    sum: 0,
    max: sum * 4 / 3,
    splitNumber: 6,
    axisLine: {
      show: false
    },
    splitLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      show: true,
      fontSize: 12,
      fontFamily: "HuaweiSans"
    }
  },
  radiusAxis: {
    type: "category",
    data: "",
    z: 10,
    axisLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      interval: 0,
      align: "right",
      margin: 20
    }
  },
  title: {
    textAlign: "center",
    textVerticalAlign: "center",
    top: "48%",
    left: "50%",
    textStyle: {
      color: "#fff",
      fontSize: 24
    },
    subtextStyle: {
      color: "#fff",
      fontSize: 36
    }
  },
  polar: {},
  series: [
    {
      type: "bar",
      data: "",
      stack: "a",
      roundCap: true,
      z: 2,
      coordinateSystem: "polar"
    },
    {
      type: "bar",
      data: "",
      stack: "a",
      roundCap: true,
      z: 1,
      coordinateSystem: "polar"
    }
  ],
  legend: {
    data: []
  }
};
function fn(iChartOption, baseOpt, sum2, theme, legendData) {
  let length = 0;
  iChartOption.data.forEach((itemd) => {
    if (length <= itemd.children.length) {
      length = itemd.children.length;
    }
  });
  if (baseOpt.series.length < length) {
    for (let i = 0; i <= length - baseOpt.series.length; i++) {
      baseOpt.series.push({
        type: "bar",
        data: "",
        stack: "a",
        roundCap: true,
        z: 2,
        coordinateSystem: "polar"
      });
    }
  }
  baseOpt.series.forEach((items, indexs) => {
    items.sum = sum2;
    items.itemStyle = {
      borderColor: theme === "dark" ? darkBackgroundColor : lightBackgroundColor,
      borderWidth: 2
    };
    if (indexs === 0) {
      items.z = 1;
    } else if (indexs === baseOpt.series.length - 1) {
      items.z = 0;
    } else {
      items.roundCap = false;
    }
  });
  for (let i = 0; i < length; i++) {
    baseOpt.series[i].data = [];
    iChartOption.data.forEach((itemd) => {
      baseOpt.series[i].data.push(itemd.children[i]);
      baseOpt.series[i].name = legendData[i];
    });
  }
}
function setSeriesData(iChartOption, baseOpt, theme) {
  iChartOption.data.forEach((item) => {
    if (!theme) {
      theme = "light";
    }
    baseOpt.angleAxis.axisLabel.color = theme === "dark" ? darkFontColor : lightFontColor;
    baseOpt.radiusAxis.axisLabel.color = theme === "dark" ? darkFontColor : lightFontColor;
    let sum2 = 0;
    baseOpt.radiusAxis.data = iChartOption.data.map((item2) => {
      return item2.name;
    });
    if (!item.children) {
      baseOpt.series[0].data = cloneDeep(iChartOption.data);
      iChartOption.data.forEach((item2) => {
        sum2 += item2.value;
      });
      baseOpt.series[0].data.forEach((item2, index) => {
        item2.itemStyle = {
          color: Array.isArray(iChartOption.color) ? getColor(iChartOption.color, index) : iChartOption.color
        };
        item2.sum = sum2;
      });
      baseOpt.series[1].data = cloneDeep(iChartOption.data);
      baseOpt.series[1].data.forEach((item2) => {
        item2.itemStyle = {
          color: theme === "dark" ? darkSecondaryColor : lightSecondaryColor
        };
        item2.value = baseOpt.angleAxis.sum - item2.value;
        item2.sum = 0;
      });
    } else {
      let legendData = [];
      iChartOption.data.forEach((item2) => {
        item2.children.forEach((itemv) => {
          sum2 += itemv.value;
        });
      });
      iChartOption.data.forEach((item2) => {
        item2.children.forEach((itemv) => {
          itemv.sum = sum2;
          legendData.push(itemv.type);
        });
      });
      legendData = Array.from(new Set(legendData));
      fn(iChartOption, baseOpt, sum2, theme, legendData);
      baseOpt.color = iChartOption.color;
    }
  });
}
function setMax(iChartOption, baseOpt) {
  if (iChartOption.calibrationValue) {
    baseOpt.angleAxis.sum = iChartOption.calibrationValue;
    baseOpt.angleAxis.max = iChartOption.calibrationValue * 4 / 3;
    iChartOption.data.forEach((item) => {
      if (item.children) {
        item.children.forEach((itemc) => {
          itemc.sumC = iChartOption.calibrationValue;
        });
      } else {
        item.sumC = iChartOption.calibrationValue;
      }
    });
  } else {
    iChartOption.data.forEach((item) => {
      if (!item.children) {
        let sum2 = 0;
        iChartOption.data.forEach((item2) => {
          sum2 += item2.value;
        });
        baseOpt.angleAxis.sum = sum2;
        baseOpt.angleAxis.max = sum2 * 4 / 3;
      } else {
        let sum2 = 0;
        iChartOption.data.forEach((item2) => {
          item2.children.forEach((itemv) => {
            sum2 += itemv.value;
          });
        });
        baseOpt.angleAxis.sum = sum2;
        baseOpt.angleAxis.max = sum2 * 4 / 3;
      }
    });
  }
}
function handleJadeJueFormatter(JadeJueTooltip, iChartOption, baseOpt) {
  JadeJueTooltip.formatter = (params) => {
    if (params.data.sum !== 0) {
      let htmlString = "";
      const value = params.data.value || params.value;
      const name = params.data.name || params.name;
      let flag = false;
      iChartOption.data.forEach((item) => {
        if (item.children) {
          flag = true;
        }
      });
      htmlString += `<span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">${flag ? params.data.type : "type"}
    : <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color
    :${params.color}"></span></span><br/><span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">name : ${name}</span><br/><span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">value:  ${value}</span><br/><span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">\u5360\u6BD4  :  ${(value / baseOpt.angleAxis.sum * 100).toFixed(2)}%</span>`;
      return htmlString;
    }
  };
}
function setTooltip$1(theme, formatter, baseOpt, iChartOption) {
  let JadeJueTooltip = {};
  switch (theme) {
    case "dark":
      JadeJueTooltip = cloneDeep(darkTooltip);
      break;
    default:
      JadeJueTooltip = cloneDeep(lightTooltip);
      break;
  }
  if (formatter) {
    JadeJueTooltip.formatter = formatter;
  } else {
    handleJadeJueFormatter(JadeJueTooltip, iChartOption, baseOpt);
  }
  JadeJueTooltip.trigger = "item";
  return JadeJueTooltip;
}
function setAxisLabel(sum2, iChartOption, baseOpt) {
  if (iChartOption.calibrationValue) {
    baseOpt.angleAxis.sum = iChartOption.calibrationValue;
    const formatter = (params) => {
      if (params === iChartOption.calibrationValue) {
        return "100%";
      }
      if (params / iChartOption.calibrationValue * 100 > 100) {
        return "";
      }
      const x = Math.ceil(params / iChartOption.calibrationValue * 100);
      return `${Math.ceil(x / 10) * 10}%`;
    };
    return formatter;
  } else {
    const formatter = (params) => {
      if (params === sum2) {
        return "100%";
      }
      if (params / sum2 * 100 > 100) {
        return "";
      }
      const x = Math.ceil(params / sum2 * 100);
      return `${Math.ceil(x / 10) * 10}%`;
    };
    return formatter;
  }
}
function setPolar(iChartOption, baseOpt) {
  if (!iChartOption.chartPosition) {
    baseOpt.polar = {
      center: ["50%", "50%"],
      radius: ["20%", "60%"]
    };
    baseOpt.series.forEach((item) => {
      item.barWidth = 8;
    });
  } else {
    baseOpt.polar.center = iChartOption.chartPosition.center;
    baseOpt.polar.radius = iChartOption.chartPosition.radius;
    baseOpt.series.forEach((item) => {
      item.barWidth = 8;
    });
  }
}
function setStartAngle(iChartOption, baseOpt) {
  if (!iChartOption.startAngle) {
    iChartOption.startAngle = 90;
  }
  baseOpt.angleAxis.startAngle = iChartOption.startAngle;
  if (!iChartOption.labelAlign) {
    iChartOption.labelAlign = "right";
  }
  baseOpt.radiusAxis.axisLabel.align = iChartOption.labelAlign;
}
function setTitle(iChartOption, baseOpt, theme) {
  if (iChartOption.title) {
    baseOpt.title.text = iChartOption.title.text;
    baseOpt.title.subtext = iChartOption.title.subtext;
    if (!iChartOption.title.top) {
      iChartOption.title.top = "48%";
    }
    baseOpt.title.top = iChartOption.title.top;
    if (!iChartOption.title.left) {
      iChartOption.title.left = "49.5%";
    }
    baseOpt.title.left = iChartOption.title.left;
    if (!iChartOption.title.textFontSize) {
      iChartOption.title.textFontSize = 20;
    }
    baseOpt.title.textStyle.fontSize = iChartOption.title.textFontSize;
    baseOpt.title.textStyle.color = theme === "dark" ? darkFontColor : lightFontColor;
    if (!iChartOption.title.subtextFontSize) {
      iChartOption.title.subtextFontSize = 12;
    }
    baseOpt.title.subtextStyle.fontSize = iChartOption.title.subtextFontSize;
    baseOpt.title.subtextStyle.color = theme === "dark" ? darkFontColor : lightFontColor;
  }
}
function setLegend(theme, iChartOption) {
  const { show: show2, position, orient: orient2 } = iChartOption.legend;
  let JadeLegend = {};
  switch (theme) {
    case "dark":
      JadeLegend = cloneDeep(darkLegend);
      break;
    default:
      JadeLegend = cloneDeep(lightLegend);
      break;
  }
  if (!show2) {
    JadeLegend.show = false;
  }
  if (orient2) {
    JadeLegend.orient = orient2;
  }
  JadeLegend.top = position.top || "auto";
  JadeLegend.left = position.left || "auto";
  JadeLegend.right = position.right || "auto";
  JadeLegend.bottom = position.bottom || "auto";
  iChartOption.data.forEach((item) => {
    if (item.children) {
      item.children.forEach((itemc) => {
        JadeLegend.data.push(itemc.type);
      });
    }
  });
  return JadeLegend;
}
class JadeJueChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption", {});
    this.baseOption = cloneDeep(BaseOption$1);
    this.iChartOption = setIChartOption(iChartOption);
    this.updateOption();
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const theme = iChartOption.theme;
    setMax(iChartOption, this.baseOption);
    setSeriesData(iChartOption, this.baseOption, theme);
    this.baseOption.tooltip = setTooltip$1(theme, iChartOption.tipHtml, this.baseOption, iChartOption);
    this.baseOption.angleAxis.axisLabel.formatter = setAxisLabel(this.baseOption.angleAxis.sum, iChartOption, this.baseOption);
    setPolar(iChartOption, this.baseOption);
    setStartAngle(iChartOption, this.baseOption);
    setTitle(iChartOption, this.baseOption, theme);
    this.baseOption.legend = setLegend(theme, iChartOption);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const BaseOption = {
  tooltip: {},
  series: [
    {
      type: "",
      data: []
    }
  ]
};
function setTooltip(theme, formatter) {
  let TreeTooltip = {};
  switch (theme) {
    case "dark":
      TreeTooltip = cloneDeep(darkTooltip);
      break;
    default:
      TreeTooltip = cloneDeep(lightTooltip);
      break;
  }
  TreeTooltip.trigger = "item";
  if (formatter) {
    TreeTooltip.formatter = formatter;
  }
  return TreeTooltip;
}
function setTheme(iChartOption) {
  iChartOption.theme = iChartOption.theme || "light";
  return iChartOption.theme;
}
function setChartPadding(type, iChartOption) {
  let defaultPadding;
  const position = { left: void 0, right: void 0, top: void 0, bottom: void 0 };
  switch (type) {
    case "LineTreeChart":
      if (!iChartOption.direction) {
        defaultPadding = [20, 150, 20, 150];
      } else if (iChartOption.direction === "top") {
        defaultPadding = [80, 20, 150, 20];
      } else if (iChartOption.direction === "bottom") {
        defaultPadding = [150, 20, 80, 20];
      } else if (iChartOption.direction === "right") {
        defaultPadding = [20, 150, 20, 150];
      } else {
        defaultPadding = [20, 150, 20, 150];
      }
      break;
    case "RingTreeChart":
      defaultPadding = [100, 150, 100, 150];
      break;
  }
  if (!iChartOption.chartPadding) {
    position.top = defaultPadding[0];
    position.right = defaultPadding[1];
    position.bottom = defaultPadding[2];
    position.left = defaultPadding[3];
  } else if (iChartOption.chartPadding.length === 1) {
    position.top = iChartOption.chartPadding[0];
    position.right = iChartOption.chartPadding[0];
    position.bottom = iChartOption.chartPadding[0];
    position.left = iChartOption.chartPadding[0];
  } else if (iChartOption.chartPadding.length === 2) {
    position.top = iChartOption.chartPadding[0];
    position.right = iChartOption.chartPadding[1];
    position.bottom = iChartOption.chartPadding[0];
    position.left = iChartOption.chartPadding[1];
  } else if (iChartOption.chartPadding.length === 3) {
    position.top = iChartOption.chartPadding[0];
    position.right = iChartOption.chartPadding[1];
    position.bottom = iChartOption.chartPadding[2];
    position.left = iChartOption.chartPadding[1];
  } else {
    position.top = iChartOption.chartPadding[0];
    position.right = iChartOption.chartPadding[1];
    position.bottom = iChartOption.chartPadding[2];
    position.left = iChartOption.chartPadding[3];
  }
  return position;
}
const label = {
  distance: 10,
  fontSize: 12
};
const lineStyle = {
  width: 1,
  curveness: 0.5
};
function handleTypeSeries(type) {
  let seriesUnit = {};
  switch (type) {
    case "LineTreeChart":
      seriesUnit = {
        type: "tree",
        data: [],
        symbol: "circle",
        layout: "orthogonal",
        label,
        lineStyle,
        itemStyle: {},
        leaves: {
          label: {}
        },
        animationDuration: 550,
        animationDurationUpdate: 750
      };
      break;
    case "RingTreeChart":
      seriesUnit = {
        type: "tree",
        data: [],
        symbol: "circle",
        layout: "radial",
        label: {
          distance: 10,
          fontSize: 12
        },
        lineStyle: {
          width: 1,
          curveness: 0.5
        },
        itemStyle: {},
        animationDuration: 550,
        animationDurationUpdate: 750
      };
      break;
  }
  return seriesUnit;
}
function setSeries(type, theme, iChartOption) {
  const series = [];
  const seriesItem = handleTypeSeries(type);
  const position = setChartPadding(type, iChartOption);
  Object.assign(seriesItem, position);
  seriesItem.data = iChartOption.data;
  seriesItem.symbolSize = iChartOption.symbolSize ? iChartOption.symbolSize : 10;
  seriesItem.initialTreeDepth = iChartOption.initialTreeDepth ? iChartOption.initialTreeDepth : 1;
  seriesItem.label.color = theme === "dark" ? darkFontColor : lightFontColor;
  seriesItem.lineStyle.color = theme === "dark" ? darkAxis : lightAxis;
  seriesItem.itemStyle.color = theme === "dark" ? "#1F55B5" : "#5990FD";
  switch (type) {
    case "LineTreeChart":
      seriesItem.edgeShape = iChartOption.lineType ? iChartOption.lineType : "curve";
      if (!iChartOption.direction) {
        seriesItem.label.position = "left";
        seriesItem.leaves.label.position = "right";
        seriesItem.orient = "LR";
      } else if (iChartOption.direction === "top") {
        seriesItem.label.position = "top";
        seriesItem.label.rotate = -90;
        seriesItem.label.align = "right";
        seriesItem.label.verticalAlign = "middle";
        seriesItem.leaves.label.position = "bottom";
        seriesItem.leaves.label.align = "left";
        seriesItem.orient = "TB";
      } else if (iChartOption.direction === "right") {
        seriesItem.label.position = "right";
        seriesItem.leaves.label.position = "left";
        seriesItem.orient = "RL";
      } else if (iChartOption.direction === "bottom") {
        seriesItem.label.position = "bottom";
        seriesItem.label.rotate = 90;
        seriesItem.label.align = "right";
        seriesItem.label.verticalAlign = "middle";
        seriesItem.leaves.label.position = "top";
        seriesItem.leaves.label.align = "left";
        seriesItem.orient = "BT";
      } else {
        seriesItem.label.position = "left";
        seriesItem.leaves.label.position = "right";
        seriesItem.orient = "LR";
      }
      break;
  }
  series.push(seriesItem);
  return series;
}
class TreeChart {
  constructor(iChartOption) {
    __publicField(this, "baseOption");
    __publicField(this, "iChartOption");
    this.baseOption = cloneDeep(BaseOption);
    this.iChartOption = iChartOption;
    this.updateOption();
  }
  setTheme(theme) {
    this.iChartOption.theme = theme;
  }
  setXAxisKey(keyName) {
    this.iChartOption.xAxis = keyName;
  }
  updateOption() {
    const iChartOption = this.iChartOption;
    const type = iChartOption.type;
    if (!type) {
      throw new Error("TreeChart must have a name");
    }
    const theme = setTheme(iChartOption);
    this.baseOption.series = setSeries(type, theme, iChartOption);
    this.baseOption.tooltip = setTooltip(theme, iChartOption.tipHtml);
  }
  getOption() {
    return this.baseOption;
  }
  setOption() {
  }
}
const _Register = class {
  static registerComp(options) {
    _Register.registeredComp[options.name] = options.component;
  }
  static getRegisteredComp(name) {
    if (name in _Register.registeredComp) {
      return _Register.registeredComp[name];
    }
    return null;
  }
};
let Register = _Register;
__publicField(Register, "registeredComp", {});
const components = [
  {
    name: "AreaChart",
    component: LineChart
  },
  {
    name: "LineChart",
    component: LineChart
  },
  {
    name: "BarChart",
    component: BarChart$1
  },
  {
    name: "PieChart",
    component: PieChart
  },
  {
    name: "GaugeChart",
    component: GaugeChart
  },
  {
    name: "SpecialChart",
    component: SpecialChart
  },
  {
    name: "BubbleChart",
    component: BubbleChart
  },
  {
    name: "RadarChart",
    component: RadarChart
  },
  {
    name: "WordCloudChart",
    component: BarChart
  },
  {
    name: "HeatMapChart",
    component: HeatMapChart
  },
  {
    name: "SankeyChart",
    component: SankeyChart
  },
  {
    name: "JadeJueChart",
    component: JadeJueChart
  },
  {
    name: "TreeChart",
    component: TreeChart
  }
];
components.forEach((comp) => {
  Register.registerComp(comp);
});
const getXaxis = (theme, addOption) => {
  let xAxis = {};
  switch (theme) {
    case "dark":
      xAxis = cloneDeep(darkXaxis);
      break;
    case "light":
      xAxis = cloneDeep(lightXaxis);
      break;
  }
  const addOptionKeys = Object.keys(addOption);
  for (let i = 0; i < addOptionKeys.length; i++) {
    const key = addOptionKeys[i];
    xAxis[key] = addOption[key];
  }
  return xAxis;
};
const getYaxis = (theme, addOption) => {
  let yAxis = {};
  switch (theme) {
    case "dark":
      yAxis = cloneDeep(darkYaxis);
      break;
    case "light":
      yAxis = cloneDeep(lightYaxis);
      break;
  }
  const addOptionKeys = Object.keys(addOption);
  for (let i = 0; i < addOptionKeys.length; i++) {
    const key = addOptionKeys[i];
    yAxis[key] = addOption[key];
  }
  return yAxis;
};
const getLegend = (theme, addOption) => {
  let legend = {};
  switch (theme) {
    case "dark":
      legend = cloneDeep(darkLegend);
      break;
    case "light":
      legend = cloneDeep(lightLegend);
      break;
  }
  const addOptionKeys = Object.keys(addOption);
  for (let i = 0; i < addOptionKeys.length; i++) {
    const key = addOptionKeys[i];
    legend[key] = addOption[key];
  }
  return legend;
};
const darkRadar = {
  axisLine: {
    lineStyle: {
      color: darkAxis,
      width: 1
    }
  },
  splitLine: {
    lineStyle: {
      color: darkAxis,
      width: 1
    }
  },
  axisName: {
    color: darkAxisLabel
  },
  center: ["50%", "50%"],
  radius: "50%",
  nameGap: 15,
  splitNumber: 4,
  shape: "circle",
  triggerEvent: false,
  indicator: []
};
const lightRadar = {
  axisLine: {
    lineStyle: {
      color: lightAxis,
      width: 1
    }
  },
  splitLine: {
    lineStyle: {
      color: lightAxis,
      width: 1
    }
  },
  axisName: {
    color: lightAxisLabel
  },
  center: ["50%", "50%"],
  radius: "50%",
  nameGap: 15,
  splitNumber: 4,
  shape: "circle",
  triggerEvent: false,
  indicator: []
};
const getRadar = (theme, addOption) => {
  let radar = {};
  switch (theme) {
    case "dark":
      radar = cloneDeep(darkRadar);
      break;
    case "light":
      radar = cloneDeep(lightRadar);
      break;
  }
  radar.axisLabel = {
    show: true,
    margin: -20
  };
  radar.splitArea = {
    show: false
  };
  Object.keys(addOption).forEach((key) => {
    radar[key] = addOption[key];
  });
  return radar;
};
const getDataZoom = (theme, addOption) => {
  let dataZoom = {};
  switch (theme) {
    case "dark":
      dataZoom = cloneDeep(darkDataZoom);
      break;
    case "light":
      dataZoom = cloneDeep(lightDataZoom);
      break;
  }
  const addOptionKeys = Object.keys(addOption);
  for (let i = 0; i < addOptionKeys.length; i++) {
    const key = addOptionKeys[i];
    dataZoom[0][key] = addOption[key];
  }
  return dataZoom;
};
const getTooltip = (theme, addOption) => {
  let tooltip = {};
  switch (theme) {
    case "dark":
      tooltip = cloneDeep(darkTooltip);
      break;
    case "light":
      tooltip = cloneDeep(lightTooltip);
      break;
  }
  const addOptionKeys = Object.keys(addOption);
  for (let i = 0; i < addOptionKeys.length; i++) {
    const key = addOptionKeys[i];
    tooltip[key] = addOption[key];
  }
  return tooltip;
};
class IntegrateChart {
  constructor() {
    __publicField(this, "instance");
    __publicField(this, "option");
    __publicField(this, "chart");
    __publicField(this, "getYAxisMaxValue", (index) => this.instance.getModel().getComponent("yAxis", index).axis.scale._extent[1]);
    __publicField(this, "getYAxisMinValue", (index) => this.instance.getModel().getComponent("yAxis", index).axis.scale._extent[0]);
    this.instance = null;
    this.option = null;
  }
  init(chartDom) {
    this.instance = echarts.init(chartDom);
    window.addEventListener("resize", this.setResize.bind(this));
  }
  setResize() {
    this.instance.resize({ width: "auto" });
  }
  getChartClass(name) {
    return Register.getRegisteredComp(name);
  }
  setSimpleOption(chartType, iChartOption, plugins) {
    const chartClass = this.getChartClass(chartType);
    this.chart = new chartClass(iChartOption, plugins, this.instance);
    this.option = this.chart.getOption();
  }
  render() {
    if (isFunction(this.option)) {
      this.option(this.instance._dom);
    } else {
      this.setOption(this.option);
      this.setSecondaryOption(this.option);
      this.renderCallBack && this.renderCallBack(this.instance);
    }
  }
  setOption(option) {
    option && this.instance.setOption(option, true);
  }
  setSecondaryOption() {
    if (this.chart.secondaryUpdateOption) {
      const YAxiMax = this.getYAxisMaxValue(0);
      const YAxiMin = this.getYAxisMinValue(0);
      this.chart.secondaryUpdateOption(YAxiMax, YAxiMin);
      this.setOption(this.option);
    }
  }
  onRenderReady(callback) {
    this.renderCallBack = callback;
  }
  showLoading(theme) {
    if (this.instance) {
      const loadingOption = {
        text: "",
        color: "#5990FD",
        zlevel: 999,
        spinnerRadius: 20,
        maskColor: theme == "dark" ? "rgba(25, 25, 25, 0.8)" : "rgba(238,238,238,0.8)"
      };
      this.instance.showLoading(loadingOption);
    }
  }
  hideLoading() {
    if (this.instance) {
      this.instance.hideLoading();
    }
  }
  bindEvents(events) {
    if (this.instance) {
      const _loopEvent = (eventName) => {
        if (typeof eventName === "string" && typeof events[eventName] === "function") {
          this.instance.off(eventName);
          this.instance.on(eventName, (param) => {
            events[eventName](param, this.instance);
          });
        }
      };
      for (const eventName in events) {
        if (Object.prototype.hasOwnProperty.call(events, eventName)) {
          _loopEvent(eventName);
        }
      }
    }
  }
  uninstall() {
    window.removeEventListener("resize", this.setResize);
  }
}
IntegrateChart.prototype.getXaxis = getXaxis;
IntegrateChart.prototype.getYaxis = getYaxis;
IntegrateChart.prototype.getLegend = getLegend;
IntegrateChart.prototype.getRadar = getRadar;
IntegrateChart.prototype.getDataZoom = getDataZoom;
IntegrateChart.prototype.getTooltip = getTooltip;
export { IntegrateChart as default };
